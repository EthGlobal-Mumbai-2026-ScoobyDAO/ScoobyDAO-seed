import argparse,base64,hashlib,json,os,pathlib,shutil,sqlite3,sys,tempfile,zipfile

def h(b):return hashlib.sha256(b).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--zip',required=True);p.add_argument('--sha256',required=True);p.add_argument('--target',required=True);a=p.parse_args();archive=pathlib.Path(a.zip).resolve();target=pathlib.Path(a.target).resolve()
 if h(archive.read_bytes())!=a.sha256.lower():raise SystemExit('ZIP hash mismatch')
 target.parent.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='scooby-seed-extract-') as temp:
  root=pathlib.Path(temp)
  with zipfile.ZipFile(archive) as z:
   names=z.namelist()
   if len(names)!=len(set(names)) or sum(i.file_size for i in z.infolist())>500_000_000:raise SystemExit('Unsafe ZIP')
   for i in z.infolist():
    q=pathlib.PurePosixPath(i.filename)
    if q.is_absolute() or '..' in q.parts or ':' in i.filename or '\\' in i.filename or (i.external_attr>>16)&0o170000==0o120000:raise SystemExit('Unsafe ZIP path')
   z.extractall(root)
  manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
  allowed=set(manifest['files'])|{'manifest.json'}
  actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
  if actual!=allowed:raise SystemExit('ZIP files differ from manifest')
  for rel,digest in manifest['files'].items():
   if h((root/rel).read_bytes())!=digest:raise SystemExit('File hash mismatch: '+rel)
  if len(manifest['pairs'])!=6 or {x['symbol'] for x in manifest['pairs']}!={'SHIB','FET','SPX','YFI','GRT','METIS'}:raise SystemExit('Unexpected pair set')
  if target.exists():
   receipt=target/'RESTORE-RECEIPT.json'
   if not receipt.is_file() or json.loads(receipt.read_text(encoding='utf-8')).get('zip_sha256')!=a.sha256.lower():raise SystemExit('Target exists and is not this verified restore; preserve or back it up and choose a new directory.')
   sys.path.insert(0,str(root/'backend'));from modules.investigation.contract_validate import verify_digest
   with sqlite3.connect((target/'state.sqlite3').resolve().as_uri()+'?mode=ro',uri=True) as c:
    for x in manifest['pairs']:
     row=c.execute('SELECT r.path,r.sha256,c.candidate_id FROM case_reference_reports l JOIN reports r ON r.id=l.report_id AND r.version=l.version JOIN cases c ON c.id=l.case_id WHERE l.case_id=? AND l.report_id=? AND l.version=?',(x['case_id'],x['report_id'],x['version'])).fetchone()
     if not row or row[1]!=x['report_sha256'] or row[2]!=x['candidate_id']:raise SystemExit('Existing restore changed; preserve and investigate')
     installed=pathlib.Path(row[0]).resolve()
     if not installed.is_relative_to((target/'bundles').resolve()):raise SystemExit('Existing report path escaped target')
     snapshot=c.execute('SELECT current_snapshot FROM cases WHERE id=?',(x['case_id'],)).fetchone()
     if not snapshot or snapshot[0]!=x['snapshot']['id']:raise SystemExit('Existing snapshot changed; preserve and investigate')
     verify_digest(installed,row[1])
   print('Already restored; six matching links and bundles verified; no changes made:',target);return
  stage=pathlib.Path(tempfile.mkdtemp(prefix=target.name+'.restore-',dir=target.parent))
  try:
   os.environ['SCOOBY_DATA']=str(stage);os.environ['SCOOBY_REPORT_RELEASE']='approved';sys.path.insert(0,str(root/'backend'))
   import store,diagnostic_import,link_local_reference
   store.init()
   for x in manifest['pairs']:
    s=x['snapshot'];record=json.loads(s['record']);evidence=json.loads(s['evidence']);assessment=json.loads(s['assessment'])
    if record['candidate_id']!=x['candidate_id'] or s['candidate_id']!=x['candidate_id'] or h(x['candidate_id'].encode())!=x['case_id']:raise ValueError('case identity mismatch')
    if h(store.dumps({'record':record,'evidence':evidence,'policy':s['policy_digest'],'assessment':assessment}).encode())!=s['id']:raise ValueError('snapshot digest mismatch')
    for path,b64 in evidence.items():
     raw=base64.b64decode(b64,validate=True)
     if path!='snapshots/'+h(raw)+'.json':raise ValueError('case evidence digest mismatch')
    with store.db() as c:
     c.execute('INSERT INTO case_snapshots VALUES(?,?,?,?,?,?,?,?)',(s['id'],s['candidate_id'],s['record'],s['evidence'],s['policy_digest'],s['assessment'],s['evaluated'],0))
     c.execute('INSERT INTO cases VALUES(?,?,?,?,?)',(x['case_id'],x['candidate_id'],s['id'],'unavailable',store.now()))
    result=diagnostic_import.install(root/x['bundle'],x['report_sha256'],x['description'])
    if (result['report_id'],result['report_version'])!=(x['report_id'],x['version']):raise ValueError('report identity mismatch')
    link_local_reference.link(x['case_id'],x['report_id'],x['version'])
   with store.db() as c:
    if c.execute('SELECT COUNT(*) FROM cases').fetchone()[0]!=6 or c.execute('SELECT COUNT(*) FROM case_reference_reports').fetchone()[0]!=6 or c.execute('SELECT COUNT(*) FROM case_decisions').fetchone()[0]!=0:raise ValueError('restore counts invalid')
    for r in c.execute('SELECT id,version,path FROM reports').fetchall():
     old=pathlib.Path(r['path']); rel=old.relative_to(stage);c.execute('UPDATE reports SET path=? WHERE id=? AND version=?',(str(target/rel),r['id'],r['version']))
   checkpoint=sqlite3.connect(stage/'state.sqlite3');checkpoint.execute('PRAGMA wal_checkpoint(TRUNCATE)');checkpoint.close()
   (stage/'RESTORE-RECEIPT.json').write_text(json.dumps({'zip_sha256':a.sha256.lower(),'case_count':6,'reference_links':6,'policy':'historical reference only; no gate/World approvals; refresh required'},indent=2)+'\n',encoding='utf-8')
   os.rename(stage,target);print('Restored six pending reference pairs to',target)
  finally:
   if stage.exists():shutil.rmtree(stage)
if __name__=='__main__':main()
