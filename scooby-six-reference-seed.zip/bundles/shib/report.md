# Investigation report — pending review

Case shib_reference_research; candidate `1:0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce`; run shib_reference_replay_20261107.

## Microstructure

The market provider returned an identity-matched base-token pool 0xCF6dAAB95c476106ECa715D48DE4b13287ffDEAa.

Status: partial
- The market provider returned an identity-matched base-token pool 0xCF6dAAB95c476106ECa715D48DE4b13287ffDEAa. [market]
- The security provider reports pool 0x811beed0119b4afce20d2583eb608c6f7af1954f; pool_fee = 0.0030; liquidity = 262223.17434055 (provider units unspecified). [security]
- The security provider reports pool 0x5764a6f2212d502bc5970f9f129ffcd61e5d7563; pool_fee = 0.01; liquidity = 15754.898579613552703893340000000000 (provider units unspecified). [security]
- The security provider reports pool 0x2f62f2b4c5fcd7570a709dec05d68ea19c82a9ec; pool_fee = 0.003; liquidity = 8858.100823614037920548910000000000 (provider units unspecified). [security]
- The security provider reports pool 0x284220e1aba6ce712aa7cd7f9d3eb1a9c25d082cceeb796beba70a3ff45f7379; pool_fee = 0.01; liquidity = 6922.793588328978698515430000000000 (provider units unspecified). [security]
- The security provider reports pool 0x773dd321873fe70553acc295b1b49a104d968cc8; pool_fee = 0.0030; liquidity = 3290.46136904 (provider units unspecified). [security]
- The security provider reports pool 0x24d3dd4a62e29770cf98810b09f89d3a90279e7a; pool_fee = 0.0030; liquidity = 935.67353829 (provider units unspecified). [security]
- The security provider reports pool 0x98c3d598cb29fa22ede2989040ebf466e6eaa6218c9b763ecb6a8537a8389de5; pool_fee = 0.003; liquidity = 485.384160419015000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0xb0cc75ed5aabb0acce7cbf0302531bb260d259c4; pool_fee = 0.003; liquidity = 312.907016361360000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0x94e4b2e24523cf9b3e631a6943c346df9687c723; pool_fee = 0.0005; liquidity = 199.913676861374848805840000000000 (provider units unspecified). [security]
- The security provider reports pool 0x6907b2dcf7835993e1b922164e7c9cb122d76c92bc127abd5ee66871120e5bf3; pool_fee = 0.01; liquidity = 186.72717960707053891801 (provider units unspecified). [security]
- The security provider reports pool 0xcecb8b15305ca7dfd64df70823adff5dc5a741c71440c388341be23e072ea8cb; pool_fee = 0.9; liquidity = 86.364356908536000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0xb64884e4ef7ad9f35bf5c13a93ee372169fd168ac12d79801ba7fae2bde1666b; pool_fee = 0.99; liquidity = 81.544750880256000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0x881d5c98866a08f90a6f60e3f94f0e461093d049; pool_fee = 0.0030; liquidity = 52.01374812 (provider units unspecified). [security]
- The security provider reports pool 0xa7220bbe389044a948ecb04ccdf51e634e8acb1d6eb16b134aa795f2cb8a55bf; pool_fee = 0.88; liquidity = 47.055371689544000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0x8b5debb8fabeff9a12a48a8711466f34f88a51e0460c1f37ca73995c332a2c32; pool_fee = 0.9; liquidity = 24.806638404996607288030000000000 (provider units unspecified). [security]
- The security provider reports pool 0x0e052a0ed8ad121ec609c021151ce453ee587ca44a7865871f9bae6617cc6b20; pool_fee = 0.99; liquidity = 24.230142963831839886500000000000 (provider units unspecified). [security]
- The security provider reports pool 0xe9131a276fd07af729b5537a429346e8affc67e0; pool_fee = 0.003; liquidity = 4.594773685216000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0x1841be5a7ec184509f220f74d779b6d6e9484e3af474b63a1ab4b1fd814fe1ff; pool_fee = 0.93; liquidity = 1.23918340170445722033 (provider units unspecified). [security]
- The security provider reports pool 0xb011ea8096ce5986f3e89b4c2c02f193c82abea8; pool_fee = 0.0030; liquidity = 0.99653687 (provider units unspecified). [security]
- The security provider reports pool 0xc8b2fcc9882dc0dd38d475d761b61ff3bb5328af4f055b841111f922a2c889f7; pool_fee = 0.000375; liquidity = 0.87315032442448011204 (provider units unspecified). [security]

## Onchain

The security provider reports holder 0xdead000000000000000042069420694206942069; supply fraction = 0.410444370884330485; tag = Dead; is_locked = 1.

Status: partial
- The security provider reports holder 0xdead000000000000000042069420694206942069; supply fraction = 0.410444370884330485; tag = Dead; is_locked = 1. [security]
- The security provider reports holder 0x02e2201576fbbefb52812f2ee7f08eb4774b481e; supply fraction = 0.064030867456809872; is_locked = 0. [security]
- The security provider reports holder 0x40b38765696e3d5d8d9d834d8aad4bb6e418e489; supply fraction = 0.047774087196843790; is_locked = 0. [security]
- The security provider reports holder 0x5a52e96bacdabb82fd05763e25335261b270efcb; supply fraction = 0.035241090956156245; is_locked = 0. [security]
- The security provider reports holder 0xa023f08c70a23abc7edfc5b6b5e171d78dfc947e; supply fraction = 0.027131378556112556; is_locked = 0. [security]
- The security provider reports holder 0xa7060aece919e4b7d9928b8418a9d30731471fa9; supply fraction = 0.016415882456435388; is_locked = 0. [security]
- The security provider reports holder 0x1d48963dd8fada6ab5c2c7b92eba81ecc5030270; supply fraction = 0.011149477038404049; is_locked = 0. [security]
- The security provider reports holder 0x47ac0fb4f2d84898e4d9e7b4dab3c24507a6d503; supply fraction = 0.009240163305385313; is_locked = 0. [security]
- The security provider reports holder 0x73af3bcf944a6559933396c1577b257e2054d935; supply fraction = 0.008400148459347337; is_locked = 0. [security]
- The security provider reports holder 0x611f7bf868a6212f871e89f7e44684045ddfb09d; supply fraction = 0.007443654140413793; is_locked = 0. [security]
- The security provider reports is_open_source = 1. [security]
- The security provider reports is_proxy = 0. [security]
- The security provider reports is_mintable = 0. [security]
- The security provider reports transfer_pausable = 0. [security]
- The security provider reports is_honeypot = 0. [security]
- GoPlus reports is_blacklisted = 0 for the candidate token. [security]
- GoPlus reports external_call = 0 for the candidate token. [security]
- GoPlus reports cannot_sell_all = 0. [security]
- GoPlus reports buy_tax = 0. [security]
- GoPlus reports sell_tax = 0. [security]
- The source provider reports runtime match status: match. [source]
- The source provider reports a verification timestamp of 2025-06-23T09:01:15Z. [source]

## Fundamentals

The market provider identifies the base token symbol as SHIB.

Status: partial
- The market provider identifies the base token symbol as SHIB. [market]
- Project attribution, social context and development require additional evidence; no Reddit content is persisted here.

## Statistical Risk

Legacy output ticker: TOKEN

Status: partial
- Legacy output ticker: TOKEN [legacy_metrics]
- Legacy output risk_assessment.risk_level: Low [legacy_metrics]
- Legacy output risk_assessment.interpretation: 1.34% maximum loss expected with 95.0% confidence over 4 day(s) [legacy_metrics]
- Original legacy metrics use 50 reconstructions; model calibration is not independently verified.

## Technical Health

The Graph token-level source returned 183 closed daily price observations.

Status: partial
- The Graph token-level source returned 183 closed daily price observations. [graph_token_daily]
- Legacy output timestamp: 2026-11-05T00:00:00 [legacy_metrics]
- Legacy output overview.latest_date: 2026-11-05 [legacy_metrics]
- Legacy output trend_health.trend_strength: bullish [legacy_metrics]
- Legacy output volatility_health.risk_level: medium [legacy_metrics]
- Legacy output consensus_health.agreement_level: medium [legacy_metrics]
- Legacy output overall_health.grade: A [legacy_metrics]
- Graph token-level data is not selected-pool history; source correctness and history adequacy remain open.
- Original legacy metrics use 50 reconstructions; model calibration is not independently verified.
