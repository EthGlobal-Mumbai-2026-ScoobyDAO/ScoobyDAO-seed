# Investigation report — pending review

Case reference_grt; candidate `1:0xc944e90c64b2c07662a292be6244bdf05cda44a7`; run reference_grt_20261107.

## Microstructure

The market provider returned an identity-matched base-token pool 0x2e81eC0B8B4022fAC83A21B2F2B4B8f5ED744D70.

Status: partial
- The market provider returned an identity-matched base-token pool 0x2e81eC0B8B4022fAC83A21B2F2B4B8f5ED744D70. [market]
- The security provider reports pool 0x2e81ec0b8b4022fac83a21b2f2b4b8f5ed744d70; pool_fee = 0.0030; liquidity = 69431.49745827 (provider units unspecified). [security]
- The security provider reports pool 0x7b504a15ef05f4eed1c07208c5815c49022a0c19; pool_fee = 0.0030; liquidity = 10983.28313660 (provider units unspecified). [security]
- The security provider reports pool 0xb06e7ed37cfa8f0f2888355dd1913e45412798c5; pool_fee = 0.003; liquidity = 1010.009533412924000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0x1dfc772ce4b18d0f441cbcc1b093aef9d0485c1e4ac97b1142c46c8f2884ecc7; pool_fee = 0.01; liquidity = 342.284401411121374881500000000000 (provider units unspecified). [security]
- The security provider reports pool 0x0e2c4be9f3408e5b1ff631576d946eb8c224b5ed; pool_fee = 0.003; liquidity = 288.690044187562614825580000000000 (provider units unspecified). [security]
- The security provider reports pool 0xdfa42ba0130425b21a1568507b084cc246fb0c8f; pool_fee = 0.0030; liquidity = 49.18766181 (provider units unspecified). [security]
- The security provider reports pool 0x4e4608eec6ab8d0f96d3bb38c863d191a63723226dc71121c7fe5b66d958355f; pool_fee = 0.88; liquidity = 30.799068662739000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0x98e51ee4aef488601c59edde2ca4a8033ea28e50749b74276e44312cce24d0fa; pool_fee = 0.003; liquidity = 2.993010528218523382680000000000 (provider units unspecified). [security]
- The security provider reports pool 0x6476340acae01ed51abd8a13e1b335e8351b47ad; pool_fee = 0.0030; liquidity = 2.97167675 (provider units unspecified). [security]
- The security provider reports pool 0xe7ef02c90c83e76cbc26ab62d521155433baba7a3b09c350b27db9cc5aa41b16; pool_fee = 0.93; liquidity = 1.53285789354348365726 (provider units unspecified). [security]
- The security provider reports pool 0x7c62fe44a893268411e9f0bb1ed944f7c8598f92; pool_fee = 0.0030; liquidity = 0.61923811 (provider units unspecified). [security]
- The security provider reports pool 0xa206921cb69c607b4e92ee5cfbc66bc31e5e7101; pool_fee = 0.0030; liquidity = 0.13924490 (provider units unspecified). [security]
- The security provider reports pool 0xbfc55576aa60743c83cf3707fca75bfddf618ed2; pool_fee = 0.0030; liquidity = 0.02656828 (provider units unspecified). [security]

### Proposed analysis

The selected Ethereum pool had reported activity and liquidity, but its executable depth is unknown.
- DEX Screener reported $139,116.45 USD in liquidity and $14,076.69 USD in rolling 24-hour volume for pool 0x2e81eC0B8B4022fAC83A21B2F2B4B8f5ED744D70. Its fetch date was 2026-11-06; the precise observation time was not supplied. Reserves are not an executable quote: price impact depends on trade size and pool state. The provider also reported 79 buys and 59 sells in that window, contrary to a claim of no activity, but these are not holder-specific execution tests. [evidence: market; inputs: market-pool, liquidity_usd_rounded, volume_24h_usd, provider_24h_buys, provider_24h_sells]
- GoPlus also listed pool 0x7b504a15ef05f4eed1c07208c5815c49022a0c19 with liquidity of 10983.28313660 in unspecified provider units. Its fetch date was 2026-11-06 and observation time was not supplied. It is a possible alternative route, not a comparable USD reserve or proof of an executable exit. [evidence: security; inputs: provider-pool-2]
- Limitation: The snapshots are historical and do not establish current depth, execution cost or market-wide liquidity.
- Follow-up: What do fresh, size-specific buy and sell quotes and simulations show for the selected pool and the alternative route?

## Onchain

The security provider reports holder 0x36aff7001294dae4c2ed4fdefc478a00de77f090; supply fraction = 0.211034505938555730; is_locked = 0.

Status: partial
- The security provider reports holder 0x36aff7001294dae4c2ed4fdefc478a00de77f090; supply fraction = 0.211034505938555730; is_locked = 0. [security]
- The security provider reports holder 0x823fd1a44a37a4be35c3b0c8b11463cc4f27396c; supply fraction = 0.075772212199144688; is_locked = 0. [security]
- The security provider reports holder 0x32ec7a59549b9f114c9d7d8b21891d91ae7f2ca1; supply fraction = 0.059797927544289332; is_locked = 0. [security]
- The security provider reports holder 0xfcb40a54be132a26c87f6bb7d2f74354ce13d96d; supply fraction = 0.051765196171113520; is_locked = 0. [security]
- The security provider reports holder 0x5b0a3c6d28b9b11770b0b838f3ff48062805b4e1; supply fraction = 0.020710077357141569; is_locked = 0. [security]
- The security provider reports holder 0x9d38093cbcfab5eba3983b54b43292bc14e82e84; supply fraction = 0.019747412580316588; is_locked = 0. [security]
- The security provider reports holder 0x5a52e96bacdabb82fd05763e25335261b270efcb; supply fraction = 0.017360450077881048; is_locked = 0. [security]
- The security provider reports holder 0xf55041e37e12cd407ad00ce2910b8269b01263b9; supply fraction = 0.016236905039047782; is_locked = 0. [security]
- The security provider reports holder 0x3a5cc8689d1b0cef2c317bc5c0ad6ce88b27d597; supply fraction = 0.015549634864924667; is_locked = 0. [security]
- The security provider reports holder 0x5eb529e12eb1de6b3c467d54b2861d3b56f63911; supply fraction = 0.015548353961304859; is_locked = 0. [security]
- The security provider reports is_open_source = 1. [security]
- The security provider reports is_proxy = 0. [security]
- The security provider reports is_mintable = 1. [security]
- The security provider reports transfer_pausable = 0. [security]
- The security provider reports is_honeypot = 0. [security]
- GoPlus reports is_blacklisted = 0 for the candidate token. [security]
- GoPlus reports external_call = 0 for the candidate token. [security]
- GoPlus reports cannot_sell_all = 0. [security]
- GoPlus reports buy_tax = 0. [security]
- GoPlus reports sell_tax = 0. [security]
- The source provider reports runtime match status: match. [source]
- The source provider reports a verification timestamp of 2024-09-19T09:53:06Z. [source]

### Proposed analysis

Reported concentration and mintability warrant verification; scanner fields do not prove a sell restriction.
- GoPlus reported that otherwise unidentified address 0x36aff7001294dae4c2ed4fdefc478a00de77f090 held a fraction corresponding to 21.1% of provider-reported total supply, and reported is_locked = 0. The fetch date was 2026-11-06; observation time was not supplied. A large balance could matter to market supply if movable, but neither the percentage nor the lock flag establishes ownership, voting power, circulating supply or a future sale. Verify the address, its balance and any transfer constraints before treating it as controlled sellable supply. [evidence: security; inputs: provider-holder-1, provider_holder_1_supply_percent]
- GoPlus reported is_mintable = 1, while reporting is_honeypot = 0, cannot_sell_all = 0 and transfer_pausable = 0. The source provider reported a runtime match; its fetch date was 2026-11-06, with observation time unspecified. Mint authority could affect supply, but the scanner flag does not establish who can mint or under what conditions. The contrary scanner fields and source match are not a coherent buy/sell simulation or proof of universal safety. Inspect the matched source and current authority state, then test the intended route and holder. [evidence: security, source; inputs: provider-is_mintable, provider-is_honeypot, goplus-cannot_sell_all, provider-transfer_pausable, source-status]
- Limitation: Provider labels and flags are reports, not independently verified current behavior.
- Limitation: No holder-specific transfer or coherent buy/sell simulation is supplied.
- Follow-up: Who can mint under the current contract state, and can the intended holder execute the intended sale?

## Fundamentals

The market provider identifies the base token symbol as GRT.

Status: partial
- The market provider identifies the base token symbol as GRT. [market]

### Proposed analysis

The ticker is identified by a market provider, but project attribution and fundamentals are not established.
- DEX Screener identifies the Ethereum base-token symbol as GRT; its fetch date was 2026-11-06, and the observation time was not supplied. This identity-matched market listing is useful context, but a ticker can be shared and does not establish project attribution, development or economic fundamentals. An independently authenticated project-to-contract link and current project records would materially improve this pillar. [evidence: market; inputs: market-symbol]
- Limitation: No authenticated project attribution, social context or development evidence is supplied.
- Follow-up: Does an authenticated project source identify this exact Ethereum contract and document current development and token economics?
- Project attribution, social context and development require additional evidence; no Reddit content is persisted here.

## Statistical Risk

Legacy output ticker: TOKEN

Status: partial
- Legacy output ticker: TOKEN [legacy_metrics]
- Legacy output risk_assessment.risk_level: Low [legacy_metrics]
- Legacy output risk_assessment.interpretation: 0.86% maximum loss expected with 95.0% confidence over 4 day(s) [legacy_metrics]

### Proposed analysis

The historical legacy run exists, but its Low label and VaR are not loss guarantees.
- The legacy run reports 50 reconstructions from 179 return data points, a risk score of 8.61 and the original label Low. Its 90%, 95% and 99% VaR values are respectively 0.6707, 0.8608 and 1.2175 on the original scale, with a 4-day horizon; the custom value is 0.8608. The legacy artifact fetch date was 2026-11-06. These are historical model outputs, not independently calibrated loss bounds or proof of safety. [evidence: legacy_metrics; inputs: legacy_vae_specific_metrics_number_of_recreations, legacy_vae_specific_metrics_data_points, legacy_risk_assessment_risk_score, legacy-risk_assessment-risk_level, legacy_var_metrics_var_90, legacy_var_metrics_var_95, legacy_var_metrics_var_99, legacy_var_metrics_var_custom, legacy_var_metrics_time_horizon_days]
- The recovered method trains on daily returns and uses Student-t reparameterization with 2.2 degrees of freedom. It assigns equal 1/50 weights to reconstruction columns in the covariance calculation; VaR applies a normal quantile, the square root of weighted covariance and the square root of the horizon, then multiplies by 100. Expected shortfall averages each reconstruction's lower 5% daily tail without horizon scaling. The run reports expected_shortfall_95 of -4.1142 and max_drawdown of -36.3253 on the original scale; the latter is the minimum reconstructed single-period return, not a conventional peak-to-trough drawdown. Reconstructions are in-sample, not independent future scenarios. [evidence: legacy_metrics; inputs: legacy_additional_risk_metrics_expected_shortfall_95, legacy_additional_risk_metrics_max_drawdown, legacy_vae_specific_metrics_number_of_recreations]
- Limitation: The original run has no fixed random seed; reconstruction independence, calibration and transfer from stocks to tokens are not established.
- Limitation: The Graph input is token-level rather than selected-pool history.
- Follow-up: Do independently verified source data and out-of-sample calibration support the model's tail estimates for this token?
- Original legacy metrics use 50 reconstructions; model calibration is not independently verified.

## Technical Health

The Graph token-level source returned 180 closed daily price observations.

Status: partial
- The Graph token-level source returned 180 closed daily price observations. [graph_token_daily]
- Legacy output timestamp: 2026-11-05T00:00:00 [legacy_metrics]
- Legacy output overview.latest_date: 2026-11-05 [legacy_metrics]
- Legacy output trend_health.trend_strength: bearish [legacy_metrics]
- Legacy output volatility_health.risk_level: low [legacy_metrics]
- Legacy output consensus_health.agreement_level: medium [legacy_metrics]
- Legacy output overall_health.grade: C [legacy_metrics]

### Proposed analysis

The historical reconstruction-based technical output is mixed, not a current trading signal.
- The Graph returned 180 closed daily token-level price observations; the associated legacy run reports 179 return data points. The Graph fetch date was 2026-11-06. The supplied series has no separate gap-interval count; a gap interval would mean an adjacent observation pair separated by more than a day, not a count of missing days. The token-level series is a counterpoint to a claim of absent history, but its correctness and relevance to the selected pool need independent checking. [evidence: graph_token_daily, legacy_metrics; inputs: graph-token-history, legacy_vae_specific_metrics_data_points, graph_token_daily_returns]
- For 2026-11-05, the legacy output labels trend strength bearish, with trend score 0.0, while reporting momentum score 100.0 and overall score 68.39207124517296, grade C. Its fetch date was 2026-11-06. These mixed indicators are calculated from reconstructions, so their agreement or disagreement is not independent market confirmation. Compare independently verified, current selected-pool prices and indicators before using them in a decision. [evidence: legacy_metrics; inputs: legacy-overview-latest_date, legacy-trend_health-trend_strength, legacy_trend_health_score, legacy_momentum_health_score, legacy_overall_health_score, legacy-overall_health-grade]
- Limitation: The historical indicators are reconstruction-based and do not establish current price direction.
- Limitation: The Graph series is token-level and not independently verified as selected-pool history.
- Follow-up: Do independently verified selected-pool observations and direct-price indicators corroborate the historical model output?
- Graph token-level data is not selected-pool history; source correctness and history adequacy remain open.
- Original legacy metrics use 50 reconstructions; model calibration is not independently verified.

## Proposed conclusion

This is a historical research judgment, not an approved or live eligibility decision. Defer committing to a trade size until executable route quotes and the reported mint authority are checked.

Proposed action: Defer committing to a trade size; obtain fresh route-specific quotes and simulations and verify current mint authority first.

Reported pool liquidity is not an executable quote, and the mintability flag identifies a supply mechanism whose authority and conditions remain unknown. [evidence: market, security; inputs: market-pool, liquidity_usd_rounded, provider-is_mintable]
- Counterevidence: The selected pool had provider-reported buys and sells, and GoPlus reported is_honeypot = 0 and cannot_sell_all = 0. This weighs against assuming a universal restriction, but does not test the intended execution. [market, security]
- Would change this view: Reconsider sizing if fresh, coherent buy/sell simulations and quotes demonstrate acceptable execution for the intended holder, route and size, and current source and authority checks explain the minting exposure.
- Would change this view: Tighten or change the recommendation if those checks reveal a material execution restriction or an unacceptable mint authority.
