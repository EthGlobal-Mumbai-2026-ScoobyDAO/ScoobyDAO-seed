# Investigation report — pending review

Case reference_metis; candidate `1:0x9e32b13ce7f2e80a01932b42553652e053d6ed8e`; run reference_metis_20261107.

## Microstructure

The market provider returned an identity-matched base-token pool 0x1c98562A2FaB5aF19D8Fb3291a36AC3C618835D9.

Status: partial
- The market provider returned an identity-matched base-token pool 0x1c98562A2FaB5aF19D8Fb3291a36AC3C618835D9. [market]
- The security provider reports pool 0x1c98562a2fab5af19d8fb3291a36ac3c618835d9; pool_fee = 0.003; liquidity = 246231.160003351622339418750000000000 (provider units unspecified). [security]
- The security provider reports pool 0xdab6d56915d36060c8d6cf29a7a84910da614603; pool_fee = 0.0030; liquidity = 1159.77130716 (provider units unspecified). [security]
- The security provider reports pool 0xd03dffd02db4b076e3eed9272a6a243a23de16e3; pool_fee = 0.0030; liquidity = 784.34283910 (provider units unspecified). [security]
- The security provider reports pool 0xcda03a04d1aeea12a540a9207afae26104197ab278d5f934a0fff5748730405e; pool_fee = 0.88; liquidity = 59.097025977576000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0x96a77f367750853580aace63c491cd5f4ced53d8cd626137b9df373cd302ea27; pool_fee = 0.9; liquidity = 1.99825205064 (provider units unspecified). [security]
- The security provider reports pool 0xedc3882fb6080e5f60f1ddaeb31e428b03d3783525a4966e663d8b91fd34f246; pool_fee = 0.98; liquidity = 1.29443602259730089045 (provider units unspecified). [security]
- The security provider reports pool 0xd9e142ad89104fe39ebacbf51bce7a3ebde1564e; pool_fee = 0.0030; liquidity = 0.00291640 (provider units unspecified). [security]

### Proposed analysis

The selected Ethereum pool had reported activity and liquidity, but the snapshot is not an executable exit quote.
- DEX Screener reported USD 577173.14 in liquidity and USD 20298.11 in rolling 24-hour volume for the Metis/WETH pool 0x1c98562A2FaB5aF19D8Fb3291a36AC3C618835D9. It also reported 86 buys and 47 sells in that window. The reported sells are meaningful counterevidence to a universal sell restriction, but do not test a particular holder or trade size. The fetch date was 2026-11-06; the precise observation time was not supplied. Obtain current, size-specific quotes and coherent buy/sell simulations before relying on this route. [evidence: market; inputs: market-pool, liquidity_usd_rounded, volume_24h_usd, provider_24h_buys, provider_24h_sells]
- GoPlus also listed pool 0xdab6d56915d36060c8d6cf29a7a84910da614603 with liquidity 1159.77130716 in unspecified provider units. It is a possible alternative route to investigate, not a comparable USD reserve or proof of an executable exit. Its fetch date was 2026-11-06; its observation time was not supplied. [evidence: security; inputs: provider-pool-2]
- Limitation: Reported pool liquidity is not depth at a particular price or a guarantee of execution.
- Limitation: The captured rolling window and selected pool do not describe every venue or current state.
- Follow-up: What are current price impact and executable buy/sell outcomes for the intended holder, route and trade size?

## Onchain

The security provider reports holder 0x3980c9ed79d2c191a89e02fa3529c60ed6e9c04b; supply fraction = 0.647442656359271255; is_locked = 0.

Status: partial
- The security provider reports holder 0x3980c9ed79d2c191a89e02fa3529c60ed6e9c04b; supply fraction = 0.647442656359271255; is_locked = 0. [security]
- The security provider reports holder 0xac3ea8f2c5f7a087ec042aaf5d72f10f63135d61; supply fraction = 0.036045397729417589; is_locked = 0. [security]
- The security provider reports holder 0x0fe382b74c3894b65c10e5c12ae60bbd8faf5b48; supply fraction = 0.034172710574955559; is_locked = 0. [security]
- The security provider reports holder 0x336500897b1de0cd41896cbf647feee90c051fc1; supply fraction = 0.028181760384427165; is_locked = 0. [security]
- The security provider reports holder 0xe759346c945381eef375fb6029360029a355340e; supply fraction = 0.023086379872310660; is_locked = 0. [security]
- The security provider reports holder 0x13bf402fc4a1c04d15ac006835e8fe2500ac5b0e; supply fraction = 0.022811218915033381; is_locked = 0. [security]
- The security provider reports holder 0xe4b3f320cfb06a60a63aa70bccb230c1a18c4e24; supply fraction = 0.012397486072905705; is_locked = 0. [security]
- The security provider reports holder 0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43; supply fraction = 0.010474209702937623; is_locked = 0. [security]
- The security provider reports holder 0x1c98562a2fab5af19d8fb3291a36ac3c618835d9; supply fraction = 0.009998750501031715; tag = UniswapV3; is_locked = 0. [security]
- The security provider reports holder 0xf4ca3035e90d2aa1aa7c74dab7c7a815cc917a20; supply fraction = 0.009402950966180995; is_locked = 0. [security]
- The security provider reports is_open_source = 1. [security]
- The security provider reports is_proxy = 0. [security]
- The security provider reports is_mintable = 1. [security]
- The security provider reports transfer_pausable = 0. [security]
- The security provider reports is_honeypot = 0. [security]
- GoPlus reports is_blacklisted = 0 for the candidate token. [security]
- GoPlus reports external_call = 0 for the candidate token. [security]
- GoPlus reports cannot_sell_all = 0. [security]
- GoPlus reports buy_tax = 0. [security]
- GoPlus reports sell_tax = 0. [security]
- The source provider reports runtime match status: match. [source]
- The source provider reports a verification timestamp of 2024-10-16T09:32:32Z. [source]

### Proposed analysis

A large provider-reported holding and a mintability flag warrant targeted verification; neither establishes abuse.
- GoPlus reported that unidentified address 0x3980c9ed79d2c191a89e02fa3529c60ed6e9c04b held 64.74% of provider-reported total supply. This percentage is a rounded conversion of its reported supply fraction, not voting power, circulating supply or proof of ownership or future sales. Concentration could matter if the balance can move into the market, but its purpose and control are unknown. The provider reported is_locked = 0; that field does not establish control. The fetch date was 2026-11-06, with no precise observation time supplied. [evidence: security; inputs: provider-holder-1, provider_holder_1_supply_percent]
- As a distinction, GoPlus tagged 0x1c98562a2fab5af19d8fb3291a36ac3c618835d9 as a UniswapV3 pool and reported it held 1.0% of provider-reported total supply; that is not an identified individual holder. GoPlus also reported is_mintable = 1, while reporting is_honeypot = 0 and cannot_sell_all = 0. These are scanner observations, not proof of mint authority, a source-code mechanism or successful execution. The security fetch date was 2026-11-06; observation time was not supplied. [evidence: security; inputs: provider-holder-9, provider_holder_9_supply_percent, provider-is_mintable, provider-is_honeypot, goplus-cannot_sell_all]
- The source-verification provider reported a runtime match, with verification timestamp 2024-10-16T09:32:32Z; its fetch date was 2026-11-06 and a separate observation time was not supplied. A match helps locate code for review but does not itself resolve current mint authority or transfer behavior. Review the matched code and current roles, then trace the large holder's purpose and control. [evidence: source; inputs: source-status, source-verified-at]
- Limitation: Holder labels, balances, lock flags and scanner fields are provider reports, not independently verified ownership or behavior.
- Limitation: No holder-specific transfer call or coherent buy/sell simulation is supplied.
- Follow-up: Who or what controls the largest reported holder, and can its balance be transferred?
- Follow-up: What minting permissions and relevant contract roles exist at a current block?

## Fundamentals

The market provider identifies the base token symbol as Metis.

Status: partial
- The market provider identifies the base token symbol as Metis. [market]

### Proposed analysis

The ticker is identified by the market provider, but project attribution and fundamental quality remain unestablished.
- DEX Screener identifies the base token as Metis, which is a useful identity starting point but not proof of project affiliation. The fetch date was 2026-11-06; the precise observation time was not supplied. No structured project-development or social evidence is supplied, so the ticker cannot support a fundamental investment thesis. Check project-controlled documentation linking the Ethereum contract to the project, then review development and governance evidence. [evidence: market; inputs: market-symbol]
- Limitation: Project attribution, development and social context are not established by the supplied material.
- Follow-up: Does authoritative project documentation identify this exact Ethereum contract, and what evidence supports its current utility and governance?
- Project attribution, social context and development require additional evidence; no Reddit content is persisted here.

## Statistical Risk

Legacy output ticker: TOKEN

Status: partial
- Legacy output ticker: TOKEN [legacy_metrics]
- Legacy output risk_assessment.risk_level: Low [legacy_metrics]
- Legacy output risk_assessment.interpretation: 1.26% maximum loss expected with 95.0% confidence over 4 day(s) [legacy_metrics]

### Proposed analysis

The historical legacy run is available, but its Low label and VaR are not reliable loss guarantees.
- The legacy output, fetched 2026-11-06, reports 90th-, 95th- and 99th-percentile VaR values of 0.9819, 1.2602 and 1.7823, respectively, on its percentage scale, over 4 days; custom VaR is 1.2602. It assigns score 12.6 and label Low. These are historical model outputs, not guaranteed loss bounds or evidence of safety. The output observation time is not supplied. [evidence: legacy_metrics; inputs: legacy_var_metrics_var_90, legacy_var_metrics_var_95, legacy_var_metrics_var_99, legacy_var_metrics_var_custom, legacy_var_metrics_time_horizon_days, legacy_risk_assessment_risk_score, legacy-risk_assessment-risk_level]
- The recovered method trains on daily returns and produces 50 in-sample reconstruction columns using Student-t reparameterization with 2.2 degrees of freedom. VaR uses a normal quantile, the square root of covariance with equal 1/50 column weights, and the square root of the horizon, multiplied by 100. Reconstructions are not independent future scenarios. The run reports 179 data points; its seed was not fixed and calibration and transfer to tokens are not established. The Graph input fetch date was 2026-11-06; its data are token-level, not selected-pool candles. [evidence: legacy_metrics, graph_token_daily; inputs: legacy_vae_specific_metrics_number_of_recreations, legacy_vae_specific_metrics_data_points, graph_token_daily_returns]
- The run reports expected_shortfall_95 of -3.0725 and max_drawdown of -18.3382 on the original output scale, plus annualized volatility 40.6305 and average daily volatility 2.5595. Expected shortfall averages each reconstruction's lower 5% daily tail and is not scaled to the VaR horizon. Despite its label, max_drawdown is the minimum reconstructed single-period return, not conventional peak-to-trough drawdown. These are model results, not observed losses. The legacy output fetch date was 2026-11-06; its observation time was not supplied. [evidence: legacy_metrics; inputs: legacy_additional_risk_metrics_expected_shortfall_95, legacy_additional_risk_metrics_max_drawdown, legacy_additional_risk_metrics_portfolio_volatility_annualized, legacy_additional_risk_metrics_average_daily_volatility]
- Limitation: The model's calibration, reconstruction independence and applicability to token returns are not established.
- Limitation: The historical Graph input is not selected-pool execution or current risk.
- Follow-up: Does an independently checked, seeded replication and out-of-sample calibration support these risk estimates?
- Original legacy metrics use 50 reconstructions; model calibration is not independently verified.

## Technical Health

The Graph token-level source returned 180 closed daily price observations.

Status: partial
- The Graph token-level source returned 180 closed daily price observations. [graph_token_daily]
- Legacy output timestamp: 2026-11-05T00:00:00 [legacy_metrics]
- Legacy output overview.latest_date: 2026-11-05 [legacy_metrics]
- Legacy output trend_health.trend_strength: bullish [legacy_metrics]
- Legacy output volatility_health.risk_level: medium [legacy_metrics]
- Legacy output consensus_health.agreement_level: medium [legacy_metrics]
- Legacy output overall_health.grade: B [legacy_metrics]

### Proposed analysis

The historical reconstruction-based grade is B, but observed token-level returns qualify the bullish model label.
- The Graph returned 180 closed daily token-level price observations and the legacy run reports 179 return data points. The supplied series covers 2026-05-10 through 2026-11-05; a separately computed gap-interval count was not supplied. A gap interval would be a pair of observations separated by more than one day, not a count of missing days. The Graph fetch date was 2026-11-06. This history is not a selected-pool candle series, and its source correctness needs independent verification. [evidence: graph_token_daily, graph_source_manifest, legacy_metrics; inputs: graph-token-history, graph_token_daily_price_usd, graph_token_daily_returns, legacy_vae_specific_metrics_data_points]
- For 2026-11-05, the legacy technical output reports overall score 73.88450631806751, grade B and bullish trend strength. These are indicators calculated on reconstructions, not independent forecasts. Against that favorable label, The Graph's observed adjacent token-level return for 2026-11-05 was -0.09483437052146704 as a fraction. This does not by itself establish a continuing trend. Both sources were fetched 2026-11-06; verify current selected-pool prices and recompute indicators on observed prices before using the historical grade for a decision. [evidence: legacy_metrics, graph_token_daily; inputs: legacy_overall_health_score, legacy-overall_health-grade, legacy-trend_health-trend_strength, legacy-overview-latest_date, graph_token_daily_returns]
- Limitation: Reconstruction-based technical indicators are historical and have no established predictive calibration.
- Limitation: Token-level Graph prices do not establish current selected-pool execution.
- Follow-up: Do independently verified, current selected-pool observations and indicators support the same technical assessment?
- Graph token-level data is not selected-pool history; source correctness and history adequacy remain open.
- Original legacy metrics use 50 reconstructions; model calibration is not independently verified.

## Proposed conclusion

The main actionable concern is the large unidentified reported holding alongside unverified mint authority and execution depth—not proof of fraud or a universal sell restriction.

Proposed action: As a research judgment, defer new exposure until the large holder and mint permissions are understood and the intended route is tested at the intended trade size.

The reported concentration and mintability create a specific supply exposure, while reported pool liquidity does not establish the price or feasibility of an intended trade. [evidence: security, market; inputs: provider-holder-1, provider_holder_1_supply_percent, provider-is_mintable, market-pool, liquidity_usd_rounded]
- Counterevidence: The selected pool had 47 provider-reported sells in its captured rolling 24-hour window, and GoPlus did not flag a honeypot or inability to sell all. This weighs against claiming a universal sell restriction, but is not a holder-specific execution test. [market, security]
- Would change this view: Reconsider deferral if current-block evidence establishes the large holder's purpose and transfer controls, verifies mint permissions, and a coherent buy/sell simulation or executable quote shows acceptable results for the intended holder, route and size.
- Would change this view: Strengthen the caution if those checks reveal exercisable supply authority or material execution problems; reassess the scope rather than assuming every pool behaves alike.
