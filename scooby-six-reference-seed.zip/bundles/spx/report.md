# Investigation report — pending review

Case reference_spx; candidate `1:0xe0f63a424a4439cbe457d80e4f4b51ad25b2c56c`; run reference_spx_20261107.

## Microstructure

The security provider reports pool 0x52c77b0cb827afbad022e6d6caf2c44452edbc39; pool_fee = 0.0030; liquidity = 5175528.65544913 (provider units unspecified).

Status: partial
- The security provider reports pool 0x52c77b0cb827afbad022e6d6caf2c44452edbc39; pool_fee = 0.0030; liquidity = 5175528.65544913 (provider units unspecified). [security]
- The security provider reports pool 0x7c706586679af2ba6d1a9fc2da9c6af59883fdd3; pool_fee = 0.003; liquidity = 52306.756486742276438498370000000000 (provider units unspecified). [security]
- The security provider reports pool 0xdc4b9fc84d439ad20e372e89c40b6ca01883aaacab6d02f8043f043987ac17c4; pool_fee = 0.01; liquidity = 13421.659480351147397104920000000000 (provider units unspecified). [security]
- The security provider reports pool 0xc02ffd29e943593d7bebf201c0c80cae1acfbd4f0b1f9a82779f81784ba3a158; pool_fee = 0.7001; liquidity = 770.607172633911000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0x67e8d9cf9f914f35825450b459aa9a3bbdfae22b9fb0a4416a9325c220852004; pool_fee = 0.69; liquidity = 88.232054039364000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0x63d4571666c193903dafb20773c2f22a8e65af6b31833e9ad6366306ec26dfda; pool_fee = 0.003; liquidity = 31.369376568210393548660000000000 (provider units unspecified). [security]
- The security provider reports pool 0x7fac8c093378d389bf361578fc946bf27507b73ef970eea4f60b62364fa90c56; pool_fee = 0.88; liquidity = 30.663711612138000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0x2b6dc76a4e533e3316c6094dedf2c559f8889e34eda9d1a8f02a822a5b95a5ba; pool_fee = 0.77; liquidity = 23.251888961211 (provider units unspecified). [security]
- The security provider reports pool 0x2e6a9e8cfb42ea2f14ff8833d71a521995378190cd1ce30e2ff1a8b8a3da750b; pool_fee = 0.003; liquidity = 3.634433407561000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0xa1a968e65a0ac11758a6656e22b42fab2e4ff42e008e85c54678cda3f08a9ec4; pool_fee = 0.93; liquidity = 1.19877600463419665361 (provider units unspecified). [security]
- The security provider reports pool 0x00ed26e794b949e18b142f9108429b74ce08ac99; pool_fee = 0.01; liquidity = 0.011176894387977200300000000000 (provider units unspecified). [security]
- The security provider reports pool 0xeb8261a88ebf20f6fc6fd402a50e864ffcefd4c6; pool_fee = 0.0030; liquidity = 0.00011594 (provider units unspecified). [security]

### Proposed analysis

Listed pools are leads for route research, not proof of executable liquidity or exit costs.
- For Ethereum pool 0x52c77b0cb827afbad022e6d6caf2c44452edbc39, GoPlus reported liquidity of 5175528.65544913 in unspecified provider units. It also listed pool 0x7c706586679af2ba6d1a9fc2da9c6af59883fdd3 with liquidity of 52306.756486742276438498370000000000 in unspecified units. Fetch date: 2026-11-06; observation time is missing. The second listing is a possible alternative route, but neither figure establishes USD reserves or an executable exit. Pool state and buy/sell quotes at the intended trade size would change that assessment. [evidence: security; inputs: provider-pool-1, provider-pool-2]
- Limitation: Provider pool listings and liquidity units are not independently verified.
- Limitation: No trade-size-specific execution or selected-pool activity data is supplied.
- Follow-up: What are the current reserves and executable buy and sell outcomes for the intended size on each candidate route?

## Onchain

The security provider reports holder 0x3ee18b2214aff97000d974cf647e7c347e8fa585; supply fraction = 0.108838840782997630; is_locked = 0.

Status: partial
- The security provider reports holder 0x3ee18b2214aff97000d974cf647e7c347e8fa585; supply fraction = 0.108838840782997630; is_locked = 0. [security]
- The security provider reports holder 0x000000000000000000000000000000000000dead; supply fraction = 0.069012821993436610; is_locked = 1. [security]
- The security provider reports holder 0xf8f061cfc030928a4acb8c4980911b4f5afc4002; supply fraction = 0.028000009000000000; is_locked = 0. [security]
- The security provider reports holder 0x7dafba1d69f6c01ae7567ffd7b046ca03b706f83; supply fraction = 0.022585225573860000; is_locked = 0. [security]
- The security provider reports holder 0xdf5e3a1ed0c14a53eee240022301ecb9d267671b; supply fraction = 0.020598603318395030; is_locked = 0. [security]
- The security provider reports holder 0x15da7556d5ed888306839bed06f868aeaedcb0d7; supply fraction = 0.017482747604971600; is_locked = 0. [security]
- The security provider reports holder 0x52c77b0cb827afbad022e6d6caf2c44452edbc39; supply fraction = 0.014624114436558780; tag = UniswapV2; is_locked = 0. [security]
- The security provider reports holder 0xd2dd7b597fd2435b6db61ddf48544fd931e6869f; supply fraction = 0.013497801751810000; is_locked = 0. [security]
- The security provider reports holder 0xaf06ff6243d166d20438d31b294b421c19994899; supply fraction = 0.012416129546840570; is_locked = 0. [security]
- The security provider reports holder 0x86cbdba59f9317d002d03aa6f24f81effc731c4a; supply fraction = 0.011393238088139420; is_locked = 0. [security]
- The security provider reports is_open_source = 1. [security]
- The security provider reports is_proxy = 0. [security]
- The security provider reports is_mintable = 0. [security]
- The security provider reports transfer_pausable = 0. [security]
- The security provider reports is_honeypot = 0. [security]
- GoPlus reports is_blacklisted = 1 for the candidate token. [security]
- GoPlus reports external_call = 0 for the candidate token. [security]
- GoPlus reports cannot_sell_all = 0. [security]
- GoPlus reports buy_tax = 0. [security]
- GoPlus reports sell_tax = 0. [security]
- The source provider reports runtime match status: match. [source]
- The source provider reports a verification timestamp of 2024-08-08T13:36:07Z. [source]

### Proposed analysis

A provider blacklist flag and a concentrated reported balance warrant targeted checks, but neither proves an active restriction or malicious control.
- GoPlus reports is_blacklisted = 1, while also reporting is_honeypot = 0 and cannot_sell_all = 0. Fetch date: 2026-11-06; observation time is missing. The flag is a provider observation, not a demonstrated source-code mechanism or active blacklist, and the contrary fields are not sell simulations. Review the matched contract's restriction logic and current state, then test coherent buys and sells for the intended holder and route. [evidence: security, source; inputs: goplus-is_blacklisted, provider-is_honeypot, goplus-cannot_sell_all, source-status]
- GoPlus reports that otherwise unidentified address 0x3ee18b2214aff97000d974cf647e7c347e8fa585 holds 10.88% of provider-reported total supply; the dead address holds 6.9%, and the provider-tagged UniswapV2 pool 0x52c77b0cb827afbad022e6d6caf2c44452edbc39 holds 1.46%. These are rounded conversions of reported fractions, not voting power, circulating supply or evidence of future sales. A substantial identifiable balance could matter to market supply if transferable, but its owner and behavior are unknown; the dead address and pool should not be treated as equivalent private holders. Fetch date: 2026-11-06; observation time is missing. Verify balances and investigate the unidentified address before drawing a control or selling conclusion. [evidence: security; inputs: provider-holder-1, provider_holder_1_supply_percent, provider-holder-2, provider_holder_2_supply_percent, provider-holder-7, provider_holder_7_supply_percent]
- Limitation: Provider flags, holder labels and lock fields do not establish ownership, present contract behavior or future sales.
- Limitation: No transfer call or coherent buy/sell simulation is supplied.
- Follow-up: Does verified restriction logic apply to the intended holder or route at a current block?
- Follow-up: Who controls the unidentified large holder, and what restrictions apply to its balance?

## Fundamentals

Project attribution, social context and development require additional evidence; no Reddit content is persisted here.

Status: unavailable

### Proposed analysis

Project attribution, social context and development require additional evidence; no Reddit content is persisted here.
- Project attribution, social context and development require additional evidence; no Reddit content is persisted here. [evidence: ; inputs: ]
- Limitation: Project attribution, social context and development require additional evidence; no Reddit content is persisted here.
- Project attribution, social context and development require additional evidence; no Reddit content is persisted here.

## Statistical Risk

Legacy output ticker: TOKEN

Status: partial
- Legacy output ticker: TOKEN [legacy_metrics]
- Legacy output risk_assessment.risk_level: Low [legacy_metrics]
- Legacy output risk_assessment.interpretation: 0.91% maximum loss expected with 95.0% confidence over 4 day(s) [legacy_metrics]

### Proposed analysis

The historical legacy run is available, but its Low label and VaR are not a reliable loss guarantee.
- The preserved legacy run reports 90th-, 95th- and 99th-percentile VaR values of 0.7055, 0.9055 and 1.2806, respectively, on its original percent scale, over a 4-day horizon. Its score is 9.05 and original risk label is Low. The legacy output was fetched on 2026-11-06; its observation time is not supplied. These are historical model outputs, not guaranteed loss bounds or proof of safety. [evidence: legacy_metrics; inputs: legacy_var_metrics_var_90, legacy_var_metrics_var_95, legacy_var_metrics_var_99, legacy_var_metrics_time_horizon_days, legacy_risk_assessment_risk_score, legacy-risk_assessment-risk_level]
- The method fits a VAE to the daily return series and produces 50 in-sample reconstruction columns, using Student-t reparameterization with 2.2 degrees of freedom. VaR applies a normal quantile to the square root of covariance with equal 1/50 column weights and the square root of the horizon, then multiplies by 100. Expected shortfall is separately averaged from each reconstruction's lower 5% daily tail and is not horizon-scaled; its reported value is -2.6528. The field max_drawdown is -17.1787 on the original scale and means the minimum reconstructed single-period return, not conventional peak-to-trough drawdown. Reconstructions are not independent future scenarios; the run has no fixed seed, and calibration and transfer to tokens are not established. An independently checked, repeatable out-of-sample evaluation would change the weight placed on these metrics. [evidence: legacy_metrics; inputs: legacy_vae_specific_metrics_number_of_recreations, legacy_additional_risk_metrics_expected_shortfall_95, legacy_additional_risk_metrics_max_drawdown]
- Limitation: The Graph input is token-level rather than selected-pool history.
- Limitation: Model independence, calibration and predictive performance are not established.
- Follow-up: Does a reproducible out-of-sample evaluation support the legacy model's risk estimates for this token?
- Original legacy metrics use 50 reconstructions; model calibration is not independently verified.

## Technical Health

The Graph token-level source returned 180 closed daily price observations.

Status: partial
- The Graph token-level source returned 180 closed daily price observations. [graph_token_daily]
- Legacy output timestamp: 2026-11-05T00:00:00 [legacy_metrics]
- Legacy output overview.latest_date: 2026-11-05 [legacy_metrics]
- Legacy output trend_health.trend_strength: bullish [legacy_metrics]
- Legacy output volatility_health.risk_level: low [legacy_metrics]
- Legacy output consensus_health.agreement_level: high [legacy_metrics]
- Legacy output overall_health.grade: A [legacy_metrics]

### Proposed analysis

The historical reconstruction-based grade is favorable, but observed daily price changes limit its usefulness as a current trading signal.
- The Graph returned 180 closed token-level daily observations; the associated adjacent-return series contains 179 returns. The source fetch date was 2026-11-06, and the dated series ends on 2026-11-05. For that final date the adjacent return was -0.10528515327641597 as a fraction. This is a historical provider-derived return, not a selected-pool execution result. Independent price history and current route data would help determine whether the movement is representative. [evidence: graph_token_daily, legacy_metrics; inputs: graph-token-history, graph_token_daily_returns, legacy_vae_specific_metrics_data_points]
- The legacy technical output, fetched 2026-11-06 and dated 2026-11-05, reports overall health 83.12398544248595 with grade A and trend strength bullish. Those favorable labels summarize reconstructed histories rather than independent future paths. The negative final Graph return is a concrete counterpoint, not a prediction; comparing independently sourced current prices and indicators with the original-series calculation would be more useful than trading on the grade alone. [evidence: legacy_metrics, graph_token_daily; inputs: legacy_overall_health_score, legacy-overall_health-grade, legacy-trend_health-trend_strength, legacy-overview-latest_date, graph_token_daily_returns]
- Limitation: Token-level subgraph prices are not selected-pool candles or independently verified market-wide prices.
- Limitation: The technical scores are historical reconstruction-based diagnostics, not validated forecasts.
- Follow-up: Do independently sourced prices and original-series indicators support the historical reconstruction-based labels?
- Graph token-level data is not selected-pool history; source correctness and history adequacy remain open.
- Original legacy metrics use 50 reconstructions; model calibration is not independently verified.

## Proposed conclusion

As a proposed research judgment, defer a new position until the intended route and transfer restrictions are checked. The historical record shows a material reported holder balance and a sharp observed daily price move, while executable exit conditions remain untested.

Proposed action: Defer new exposure until a current contract-state review and trade-size-specific route tests are complete; do not treat this historical diagnostic as approval or as proof of a universal sell restriction.

The reported large holder and historical daily price movement create identifiable exposure, while the blacklist flag's operational meaning and executable exit are unresolved. [evidence: security, graph_token_daily; inputs: provider-holder-1, provider_holder_1_supply_percent, goplus-is_blacklisted, graph_token_daily_returns]
- Counterevidence: GoPlus reports no honeypot and no inability to sell all, and lists another possible route; these are useful counterpoints but not demonstrated executions. [security]
- Would change this view: Reconsider after independently reviewing current restriction logic and state for the intended holder, and observing coherent buy and sell simulations at the intended size on the chosen route.
- Would change this view: Increase or reduce concern about concentration after verifying the large holder's balance, control and transferability.
- Would change this view: Reassess price risk using independently sourced current history and a reproducible out-of-sample model evaluation.
