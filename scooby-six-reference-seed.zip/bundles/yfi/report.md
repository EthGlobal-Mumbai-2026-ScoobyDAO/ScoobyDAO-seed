# Investigation report — pending review

Case reference_yfi; candidate `1:0x0bc529c00c6401aef6d220be8c6ea1667f6ad93e`; run reference_yfi_20261107.

## Microstructure

The market provider returned an identity-matched base-token pool 0xC26b89A667578ec7b3f11b2F98d6Fd15C07C54ba.

Status: partial
- The market provider returned an identity-matched base-token pool 0xC26b89A667578ec7b3f11b2F98d6Fd15C07C54ba. [market]
- The security provider reports pool 0x2fdbadf3c4d5a8666bc06645b8358ab803996e28; pool_fee = 0.0030; liquidity = 63606.26917147 (provider units unspecified). [security]
- The security provider reports pool 0x088ee5007c98a9677165d78dd2109ae4a3d04d0c; pool_fee = 0.0030; liquidity = 56558.14482031 (provider units unspecified). [security]
- The security provider reports pool 0x04916039b1f59d9745bf6e0a21f191d1e0a84287; pool_fee = 0.003; liquidity = 4935.715587512432679992750000000000 (provider units unspecified). [security]
- The security provider reports pool 0x2e8daf55f212be91d3fa882cceab193a08fddeb2; pool_fee = 0.01; liquidity = 134.439341008367393255400000000000 (provider units unspecified). [security]
- The security provider reports pool 0x68f0ecb1066527f5365dd62001af040d95a3efafb79ec276b7aa09ec374ecbec; pool_fee = 0.88; liquidity = 60.825358033128000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0xf80960072b76804d4e0c12bebe784e6bf95883b9; pool_fee = 0.0030; liquidity = 13.78468799 (provider units unspecified). [security]
- The security provider reports pool 0xe37ad1636716ff581145ab61b7d0209a1ce011040992cbcaa51c09c37986c3eb; pool_fee = 0.93; liquidity = 2.55150217320632975055 (provider units unspecified). [security]
- The security provider reports pool 0xf173a7a055340c91dbdf3083ce3babaa7535a03c; pool_fee = 0.0030; liquidity = 2.24692869 (provider units unspecified). [security]
- The security provider reports pool 0x3a5747cf4e21861e2d0d3d51a0e8737ab4dfadc8; pool_fee = 0.0030; liquidity = 1.22417903 (provider units unspecified). [security]
- The security provider reports pool 0xf5fbc6ca5c677f1c977ed3a064b9dda14c5e241b; pool_fee = 0.0030; liquidity = 0.44587194 (provider units unspecified). [security]
- The security provider reports pool 0xacd2556f64d4be9aaa205278895653d3e6d639ae; pool_fee = 0.0030; liquidity = 0.28012933 (provider units unspecified). [security]
- The security provider reports pool 0xde37cd310c70e7fa9d7ed3261515b107d5fe1f2d; pool_fee = 0.0030; liquidity = 0.02081044 (provider units unspecified). [security]
- The security provider reports pool 0x3cd132ac73a4043bb4f1674369e70be6f88edd73; pool_fee = 0.0030; liquidity = 0.01985735 (provider units unspecified). [security]
- The security provider reports pool 0xdeb9725e10642d1de906923f5b57851aa92a70aa; pool_fee = 0.0030; liquidity = 0.00000000 (provider units unspecified). [security]

### Proposed analysis

The selected Curve pool showed reported trading activity and liquidity, but neither establishes an executable quote for a particular order.
- For Ethereum pool 0xC26b89A667578ec7b3f11b2F98d6Fd15C07C54ba, DEX Screener reported liquidity of 519657.27 USD, 24-hour volume of 33562.1 USD, 30 buys and 38 sells. The fetch date was 2026-11-06; the precise observation time is not supplied. Reported sells are meaningful counterevidence to a universal sell restriction, but transaction counts do not test a particular holder or trade size. Pool liquidity is not an executable quote: price impact and available exit depth depend on the route, order size and state at execution. [evidence: market; inputs: market-pool, liquidity_usd_rounded, volume_24h_usd, provider_24h_buys, provider_24h_sells]
- GoPlus also reports pool 0x2fdbadf3c4d5a8666bc06645b8358ab803996e28 with liquidity of 63606.26917147 in unspecified provider units. Its fetch date was 2026-11-06 and the observation time is missing. This is a possible alternative route to investigate, not a comparable USD reserve or proof of an executable exit. [evidence: security; inputs: provider-pool-1]
- Limitation: The observations are historical provider snapshots, not current quotes or holder-specific executions.
- Limitation: No order-size-specific price impact or route simulation is supplied.
- Follow-up: What do fresh, size-specific buy and sell quotes and a coherent execution simulation show for the intended route?

## Onchain

The security provider reports holder 0x86e6350cb5ae99def9fb12fb3b5064c4dc50d182; supply fraction = 0.076870568629629802; is_locked = 0.

Status: partial
- The security provider reports holder 0x86e6350cb5ae99def9fb12fb3b5064c4dc50d182; supply fraction = 0.076870568629629802; is_locked = 0. [security]
- The security provider reports holder 0xf977814e90da44bfa03b6295a0616a897441acec; supply fraction = 0.055322805869197621; is_locked = 0. [security]
- The security provider reports holder 0x979d08767aee8bce351be64cfec646bf92293674; supply fraction = 0.053092323138458032; is_locked = 0. [security]
- The security provider reports holder 0x90c1f9220d90d3966fbee24045edd73e1d588ad5; supply fraction = 0.041659844187854389; is_locked = 0. [security]
- The security provider reports holder 0x42b25284e8ae427d79da78b65dffc232aaecc016; supply fraction = 0.037592051737459624; is_locked = 0. [security]
- The security provider reports holder 0x15da7556d5ed888306839bed06f868aeaedcb0d7; supply fraction = 0.030814157802869143; is_locked = 0. [security]
- The security provider reports holder 0x47ac0fb4f2d84898e4d9e7b4dab3c24507a6d503; supply fraction = 0.024545900834560628; is_locked = 0. [security]
- The security provider reports holder 0x073f564419b625a45d8aea3bb0de4d5647113ad7; supply fraction = 0.022408133376152293; is_locked = 0. [security]
- The security provider reports holder 0xfeb4acf3df3cdea7399794d0869ef76a6efaff52; supply fraction = 0.020898249843571314; is_locked = 0. [security]
- The security provider reports holder 0x5a52e96bacdabb82fd05763e25335261b270efcb; supply fraction = 0.019932007854688267; is_locked = 0. [security]
- The security provider reports is_open_source = 1. [security]
- The security provider reports is_proxy = 0. [security]
- The security provider reports is_mintable = 1. [security]
- The security provider reports transfer_pausable = 0. [security]
- The security provider reports is_honeypot = 0. [security]
- GoPlus reports is_blacklisted = 0 for the candidate token. [security]
- GoPlus reports external_call = 0 for the candidate token. [security]
- GoPlus reports cannot_sell_all = 0. [security]
- GoPlus reports buy_tax = 0. [security]
- GoPlus reports sell_tax = 0. [security]
- The source provider reports runtime match status: match. [source]
- The source provider reports a verification timestamp of 2024-08-08T14:46:38Z. [source]

### Proposed analysis

GoPlus reports mintability and a concentrated holder balance, alongside flags that do not report a honeypot or an inability to sell all.
- GoPlus reports is_mintable = 1 and attributes 7.69% of its reported total supply to 0x86e6350cb5ae99def9fb12fb3b5064c4dc50d182, an otherwise unidentified address in the structured claims. The percentage is a rounded conversion of the provider's supply fraction, not evidence of voting power, ownership or a future sale; its is_locked = 0 flag does not establish control. Mint authority and a large balance could matter to supply or market exposure, but the supplied flags do not establish who can mint or what the holder will do. The GoPlus fetch date was 2026-11-06; the observation time is missing. [evidence: security; inputs: provider-is_mintable, provider-holder-1, provider_holder_1_supply_percent]
- The strongest counterpoint is that GoPlus reports is_honeypot = 0 and cannot_sell_all = 0; these are scanner observations, not a coherent buy-and-sell test or proof of universal safety. The source provider also reports a runtime match, but that does not establish current authority or execution behavior. The source fetch date was 2026-11-06, with observation time missing. [evidence: security, source; inputs: provider-is_honeypot, goplus-cannot_sell_all, source-status]
- Limitation: No structured source-code mechanism, current mint-authority state or holder-specific execution test is supplied.
- Limitation: Provider holder labels and balances are reports, not independently verified ownership.
- Follow-up: At a specified recent block, who can mint and under what constraints, and can the intended holder complete the intended sell route?

## Fundamentals

The market provider identifies the base token symbol as YFI.

Status: partial
- The market provider identifies the base token symbol as YFI. [market]

### Proposed analysis

The supplied fundamental evidence identifies the market symbol but does not establish project quality or token rights.
- DEX Screener identifies the matched base token as YFI. The fetch date was 2026-11-06 and the precise observation time is missing. This supports a bounded ticker identification, which is useful for avoiding an obvious mismatch, but a ticker alone does not authenticate project attribution, development activity or the economic rights of the token. The matched market listing is the strongest available counterpoint to a complete absence of identity information. [evidence: market; inputs: market-symbol]
- Limitation: No supplied structured evidence establishes project development, governance rights, revenue or social context.
- Follow-up: Do independently verified project sources connect this Ethereum contract to the claimed project and describe the token's rights and current development?
- Project attribution, social context and development require additional evidence; no Reddit content is persisted here.

## Statistical Risk

Legacy output ticker: TOKEN

Status: partial
- Legacy output ticker: TOKEN [legacy_metrics]
- Legacy output risk_assessment.risk_level: Low [legacy_metrics]
- Legacy output risk_assessment.interpretation: 0.87% maximum loss expected with 95.0% confidence over 4 day(s) [legacy_metrics]

### Proposed analysis

The historical legacy run reports a Low label, but its reconstructed VaR is not a verified loss limit.
- The legacy run reports 179 return data points and 50 reconstructions. It reports VaR on its original scale as 0.6743 at 90%, 0.8654 at 95%, and 1.2239 at 99%, with a 4-day horizon; its risk score is 8.65 and original label is Low. The derived artifact was fetched on 2026-11-06. The underlying Graph history is token-level rather than a selected-pool series, and the model's calibration is not independently established. [evidence: legacy_metrics; inputs: legacy_vae_specific_metrics_data_points, legacy_vae_specific_metrics_number_of_recreations, legacy_var_metrics_var_90, legacy_var_metrics_var_95, legacy_var_metrics_var_99, legacy_var_metrics_time_horizon_days, legacy_risk_assessment_risk_score, legacy-risk_assessment-risk_level]
- The recovered method trains on daily returns and uses Student-t reparameterization with 2.2 degrees of freedom. It weights the 50 reconstruction columns equally at 1/50 for covariance; VaR is the normal quantile times the square root of weighted covariance and the square root of the horizon, multiplied by 100. Expected shortfall, reported as -4.2719 on the original scale, instead averages each reconstruction's lower 5% daily tail and is not horizon-scaled. The field max_drawdown, reported as -17.6268, is the minimum reconstructed single-period return, not peak-to-trough drawdown. These are in-sample reconstructions, not independent future scenarios. Despite the original interpretation's maximum-loss wording, VaR is not a guaranteed loss bound. [evidence: legacy_metrics; inputs: legacy_vae_specific_metrics_number_of_recreations, legacy_var_metrics_time_horizon_days, legacy_additional_risk_metrics_expected_shortfall_95, legacy_additional_risk_metrics_max_drawdown, legacy-risk_assessment-interpretation]
- Limitation: The original run has no fixed random seed; reconstruction independence, calibration and transfer from stocks to tokens are not established.
- Limitation: The model is historical and cannot establish contract safety or executable liquidity.
- Follow-up: Would independent source verification and out-of-sample calibration support the model's risk estimates for this token?
- Original legacy metrics use 50 reconstructions; model calibration is not independently verified.

## Technical Health

The Graph token-level source returned 180 closed daily price observations.

Status: partial
- The Graph token-level source returned 180 closed daily price observations. [graph_token_daily]
- Legacy output timestamp: 2026-11-05T00:00:00 [legacy_metrics]
- Legacy output overview.latest_date: 2026-11-05 [legacy_metrics]
- Legacy output trend_health.trend_strength: bullish [legacy_metrics]
- Legacy output volatility_health.risk_level: low [legacy_metrics]
- Legacy output consensus_health.agreement_level: high [legacy_metrics]
- Legacy output overall_health.grade: B [legacy_metrics]

### Proposed analysis

The legacy technical grade is favorable, but the reconstructed indicators and the actual historical token-level prices are not a current trading signal.
- The Graph supplied 180 closed daily token-level price observations from 2026-05-10 through 2026-11-05; the legacy run reports 179 return data points. The Graph fetch date was 2026-11-06. The dated series reports 2700.85873329254 USD per token on 2026-07-06 and 2204.9716214687814 USD per token on 2026-07-07, illustrating that observed daily values can change materially. These are provider observations, not a selected-pool execution price or an explanation of the movement. [evidence: graph_token_daily, graph_source_manifest, legacy_metrics; inputs: graph-token-history, graph_token_daily_price_usd, legacy_overview_analysis_period_days]
- For 2026-11-05, the legacy technical output gives an overall score of 74.28445680756492 and grade B, with trend labeled bullish. Its bullish MACD ratio was 0.36, a counterpoint to treating that label as uniform momentum. The derived output fetch date was 2026-11-06. These indicators are computed from reconstructions, so their agreement does not represent independent future scenarios or validate a live signal. [evidence: legacy_metrics; inputs: legacy-timestamp, legacy_overall_health_score, legacy-overall_health-grade, legacy-trend_health-trend_strength, legacy_momentum_health_bullish_macd_ratio]
- Limitation: Graph token-level prices are not selected-pool candles, and source correctness is not independently established.
- Limitation: No structured gap-interval count or precomputed endpoint-change percentage is supplied.
- Limitation: The technical output is historical and its reconstruction-based indicators are not independently calibrated.
- Follow-up: Do independently sourced, current selected-route prices and directly calculated indicators corroborate the historical diagnostic?
- Graph token-level data is not selected-pool history; source correctness and history adequacy remain open.
- Original legacy metrics use 50 reconstructions; model calibration is not independently verified.

## Proposed conclusion

Treat this as a historical research judgment, not live approval: obtain a current, size-specific route check and verify mint authority before committing to a trade. The evidence supports caution about execution and supply exposure, not a finding of fraud or a universal sell restriction.

Proposed action: Before committing to a trade, check a fresh quote and buy/sell simulation for the intended size and route, and verify current mint authority at a specified block.

The historical Curve pool snapshot cannot guarantee execution at the intended size, and GoPlus's mintable flag leaves a supply-control question that a trade quote cannot answer. The reconstruction-based risk label does not resolve either exposure. [evidence: market, security, legacy_metrics; inputs: market-pool, liquidity_usd_rounded, provider-is_mintable, legacy-risk_assessment-risk_level]
- Counterevidence: DEX Screener reported 38 sells in the selected pool's 24-hour window, and GoPlus reported is_honeypot = 0 and cannot_sell_all = 0. These weigh against a universal sell-restriction claim, although they do not test the intended holder and order. [market, security]
- Would change this view: A fresh, coherent buy-and-sell simulation and acceptable quote for the intended holder, size and route, together with verified mint-authority constraints, would support reconsidering a trade.
- Would change this view: A failed coherent simulation, materially adverse execution quote or verified concerning mint authority would warrant stronger, specifically scoped caution.
