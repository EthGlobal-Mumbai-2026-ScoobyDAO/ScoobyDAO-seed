# Investigation report — pending review

Case reference_fet; candidate `1:0xaea46a60368a7bd060eec7df8cba43b7ef41ad85`; run reference_fet_20261107.

## Microstructure

The market provider returned an identity-matched base-token pool 0x948b54A93f5aD1df6B8bFF6Dc249D99CA2EcA052.

Status: partial
- The market provider returned an identity-matched base-token pool 0x948b54A93f5aD1df6B8bFF6Dc249D99CA2EcA052. [market]
- The security provider reports pool 0x3d8ae8c4fc122cb1d9c905b859680075100839e1853ff13d6351e4d9f5bf9528; pool_fee = 0.01; liquidity = 105018.11539115225620664945 (provider units unspecified). [security]
- The security provider reports pool 0x7ddad1eddb0b1077c0c1d916abf3bf2e342315f8; pool_fee = 0.003; liquidity = 5019.737202041484 (provider units unspecified). [security]
- The security provider reports pool 0x80235dd0d2b0fbac1fc5b9e04d4af3e030efd2b1026823affec8f5a6c9306c38; pool_fee = 0.003; liquidity = 4246.275366660858806847000000000000 (provider units unspecified). [security]
- The security provider reports pool 0x6d36a91a3389ad541dc3bfb8ed8a5b4c78b8ea4be0f911def3cadf805f3d856c; pool_fee = 0.7; liquidity = 2892.76813721853292489440 (provider units unspecified). [security]
- The security provider reports pool 0x382470050e171a2e5b5cff3baadc7549e4ad4a8b2992fdcad58613ce091c351c; pool_fee = 0.06; liquidity = 2419.425661841592 (provider units unspecified). [security]
- The security provider reports pool 0x744159757cac173a7a3ecf5e97adb10d1a725377; pool_fee = 0.003; liquidity = 2039.891376163515862293460000000000 (provider units unspecified). [security]
- The security provider reports pool 0x948b54a93f5ad1df6b8bff6dc249d99ca2eca052; pool_fee = 0.01; liquidity = 1789.964049131266953873500000000000 (provider units unspecified). [security]
- The security provider reports pool 0x4042a04c54ef133ac2a3c93db69d43c6c02a330b; pool_fee = 0.0030; liquidity = 71.65290019 (provider units unspecified). [security]
- The security provider reports pool 0xd738acd80e757fd8222ed9562916fc409e558c0f5f34173610ef6c6345f92a10; pool_fee = 0.69; liquidity = 24.065176833780000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0xf4085ccbf42eac863b5aa632d76640cce590cbcb27cc2703c7ad5d4b3b52ca9f; pool_fee = 0.7; liquidity = 6.333948631644000000000000000000 (provider units unspecified). [security]
- The security provider reports pool 0xe769af239d74ab90ac9b506a873a4e6b4ba389f9a3076334bba4b6cfd4f388fb; pool_fee = 0.93; liquidity = 2.7228862143534412075 (provider units unspecified). [security]
- The security provider reports pool 0x3910c1a0d1e1ab34425999a451f9ffdc2fa98a671f428bc593dd3bd2070478af; pool_fee = 0.0268; liquidity = 0.998610202125 (provider units unspecified). [security]
- The security provider reports pool 0xf0474996e90e6a2c1bf51bc291fc7779b398e92381a192f42bd5b09cb350447b; pool_fee = 0.0095; liquidity = 0.456091889457 (provider units unspecified). [security]
- The security provider reports pool 0xee2075ccaceb41d54c513073a26f940328f7e0df; pool_fee = 0.0030; liquidity = 0.02584857 (provider units unspecified). [security]
- The security provider reports pool 0x61b4666a6b85aabde1a60e69a1e7e5caf659dfdd; pool_fee = 0.0030; liquidity = 0.00000100 (provider units unspecified). [security]

### Proposed analysis

The selected Ethereum pool had reported liquidity and trading activity, but neither establishes an executable quote for a particular trade.
- DEX Screener reported 120777.01 USD in liquidity and 4426.86 USD in rolling 24-hour volume for pool 0x948b54A93f5aD1df6B8bFF6Dc249D99CA2EcA052. Its fetch date was 2026-11-06; the observation time was not supplied. Liquidity can change and a trade moves through available pool depth, so the reported total is not the amount a holder can necessarily exit without price impact. The provider also reported 31 buys and 35 sells in that pool’s rolling 24-hour window, evidence of activity but not a holder-specific execution test. [evidence: market; inputs: market-pool, liquidity_usd_rounded, volume_24h_usd, provider_24h_buys, provider_24h_sells]
- GoPlus also listed pool 0x3d8ae8c4fc122cb1d9c905b859680075100839e1853ff13d6351e4d9f5bf9528 with liquidity of 105018.11539115225620664945 in unspecified provider units. Its fetch date was 2026-11-06; the observation time was not supplied. This is a possible alternative route to investigate, not a comparable USD reserve or proof of an executable exit. [evidence: security; inputs: provider-pool-1]
- Limitation: The reported pool snapshot is historical, not a current quote or a market-wide liquidity measurement.
- Limitation: The available transaction counts do not identify trade sizes or establish execution for a particular holder.
- Follow-up: What are current executable buy and sell quotes, including price impact, for the intended size on the selected pool and verified alternative routes?

## Onchain

The security provider reports holder 0xf58db6a8c84b454cc8d2980b0d8b6017d0b645dc; supply fraction = 0.102251380092880573; is_locked = 0.

Status: partial
- The security provider reports holder 0xf58db6a8c84b454cc8d2980b0d8b6017d0b645dc; supply fraction = 0.102251380092880573; is_locked = 0. [security]
- The security provider reports holder 0x5a8de252ea228dece61638c336fe43ac8166166a; supply fraction = 0.064768524627371999; is_locked = 0. [security]
- The security provider reports holder 0x9d38093cbcfab5eba3983b54b43292bc14e82e84; supply fraction = 0.047253589648060069; is_locked = 0. [security]
- The security provider reports holder 0xfcf15c599de861cceee7463595181d0ab22a6fb1; supply fraction = 0.042195582021846746; is_locked = 0. [security]
- The security provider reports holder 0x5e0c3ea93b8aa38ee2b8c58bf21cd8efc1794a5f; supply fraction = 0.040926606376897247; is_locked = 0. [security]
- The security provider reports holder 0xdbfc56ee0791193140b8658c0680b66de2bc347d; supply fraction = 0.039021173304463457; is_locked = 0. [security]
- The security provider reports holder 0x77fb357f55bef5a70d30663955f8c9f35794df0e; supply fraction = 0.034316393108689488; is_locked = 0. [security]
- The security provider reports holder 0xe35d9a2f30cfbec951e85f2535328e7b1e191aa9; supply fraction = 0.031151066213473846; is_locked = 0. [security]
- The security provider reports holder 0x76ec5a0d3632b2133d9f1980903305b62678fbd3; supply fraction = 0.030448070371983774; is_locked = 0. [security]
- The security provider reports holder 0x351bac612b50e87b46e4b10a282f632d41397de2; supply fraction = 0.029699725519922169; is_locked = 0. [security]
- The security provider reports is_open_source = 1. [security]
- The security provider reports is_proxy = 0. [security]
- The security provider reports is_mintable = 1. [security]
- The security provider reports transfer_pausable = 1. [security]
- The security provider reports is_honeypot = 0. [security]
- GoPlus reports is_blacklisted = 0 for the candidate token. [security]
- GoPlus reports external_call = 0 for the candidate token. [security]
- GoPlus reports buy_tax = 0. [security]
- GoPlus reports sell_tax = 0. [security]
- The source provider reports runtime match status: match. [source]
- The source provider reports a verification timestamp of 2024-08-08T14:07:07Z. [source]

### Proposed analysis

Provider-reported pause and mint capabilities warrant checking current authority and state; a universal sell restriction is not established.
- GoPlus reported transfer_pausable = 1 and is_mintable = 1 for the Ethereum token, with fetch date 2026-11-06 and no supplied observation time. If confirmed and usable, pausing could interrupt transfers and minting could change supply; the flags alone do not establish who holds authority, whether a pause is active, or whether minting occurred. The source provider separately reported a runtime match, fetched on 2026-11-06, but that match is not a behavioral or current-state test. [evidence: security, source; inputs: provider-transfer_pausable, provider-is_mintable, source-status]
- GoPlus reported is_honeypot = 0 and sell_tax = 0, while DEX Screener reported 35 sells in the selected pool’s rolling 24-hour window. These are meaningful counterpoints to a universal sell-restriction allegation, but neither is a coherent buy-and-sell simulation for the reader’s holder, size and route. The GoPlus and DEX Screener fetch dates were 2026-11-06; observation times were not supplied. [evidence: security, market; inputs: provider-is_honeypot, goplus-sell_tax, provider_24h_sells]
- GoPlus reported that otherwise unidentified address 0xf58db6a8c84b454cc8d2980b0d8b6017d0b645dc held 10.23 percent of provider-reported total supply, a rounded conversion of its reported fraction, and marked is_locked = 0. The fetch date was 2026-11-06; observation time was not supplied. A substantial reported balance can matter if it is transferred or sold, but the address’s identity, control and future behavior are unknown; the lock field does not establish control or voting power. [evidence: security; inputs: provider-holder-1, provider_holder_1_supply_percent]
- Limitation: Provider flags are observations, not verified source-code mechanisms or current contract state.
- Limitation: No holder-specific transfer call or coherent route-specific buy-and-sell simulation is supplied.
- Follow-up: At a recent block, does verified code implement minting and transfer pausing, who can exercise those powers, and is the token paused?
- Follow-up: Can the intended holder complete a coherent buy-and-sell simulation at the intended size on the chosen route?

## Fundamentals

The market provider identifies the base token symbol as FET.

Status: partial
- The market provider identifies the base token symbol as FET. [market]

### Proposed analysis

The provider’s FET ticker identifies a market listing, not independently verified project fundamentals.
- DEX Screener identifies the base-token symbol as FET; its fetch date was 2026-11-06 and the observation time was not supplied. This is useful for locating the listing, but ticker reuse means it cannot establish project attribution, development, adoption or value. The identity-matched listing is the available counterpoint to treating the project as wholly unidentified, not independent confirmation of those fundamentals. [evidence: market; inputs: market-symbol]
- Limitation: No project attribution, development or social evidence is supplied.
- Follow-up: Do authoritative project sources independently link this Ethereum contract address to the claimed project, and what current development evidence supports that attribution?
- Project attribution, social context and development require additional evidence; no Reddit content is persisted here.

## Statistical Risk

Legacy output ticker: TOKEN

Status: partial
- Legacy output ticker: TOKEN [legacy_metrics]
- Legacy output risk_assessment.risk_level: Low [legacy_metrics]
- Legacy output risk_assessment.interpretation: 1.51% maximum loss expected with 95.0% confidence over 4 day(s) [legacy_metrics]

### Proposed analysis

The legacy run reports Low risk, but its in-sample reconstruction estimate is not a reliable loss bound.
- The legacy output, fetched 2026-11-06 and based on The Graph token-level data, reports VaR values of 1.1781, 1.5121 and 2.1386 on its original scale at the 90th, 95th and 99th confidence percentiles, respectively, for a 4-day horizon. Its score is 15.12 with the original label Low. That label is a counterpoint to a blanket high-risk model conclusion, but the output’s stated maximum-loss interpretation must not be treated as a guarantee or proof of safety. [evidence: legacy_metrics; inputs: legacy_var_metrics_var_90, legacy_var_metrics_var_95, legacy_var_metrics_var_99, legacy_var_metrics_time_horizon_days, legacy_risk_assessment_risk_score, legacy-risk_assessment-risk_level, legacy-risk_assessment-interpretation]
- The recovered method trains on daily returns and generates 50 in-sample reconstruction columns using Student-t reparameterization with 2.2 degrees of freedom. It weights each column 1/50 in the covariance, then multiplies the normal quantile by the square roots of weighted covariance and horizon and by 100. The separately averaged lower 5% daily-tail expected shortfall is -9.7739 on the original scale and is not scaled to the VaR horizon. The field max_drawdown is -47.6389 on that scale: it is the minimum reconstructed single-period return, not conventional peak-to-trough drawdown. Reconstructions are not independent future scenarios; the run has no fixed seed and its calibration and transfer to tokens are not established. [evidence: legacy_metrics; inputs: legacy_vae_specific_metrics_number_of_recreations, legacy_vae_specific_metrics_data_points, legacy_additional_risk_metrics_expected_shortfall_95, legacy_additional_risk_metrics_max_drawdown]
- Limitation: The source is token-level Graph history, not selected-pool candles, and its accuracy and model calibration require independent verification.
- Limitation: The reconstruction outputs do not establish future losses or sellability.
- Follow-up: Does an independently checked, reproducible out-of-sample evaluation support the model’s risk estimates on this token?
- Original legacy metrics use 50 reconstructions; model calibration is not independently verified.

## Technical Health

The Graph token-level source returned 180 closed daily price observations.

Status: partial
- The Graph token-level source returned 180 closed daily price observations. [graph_token_daily]
- Legacy output timestamp: 2026-11-05T00:00:00 [legacy_metrics]
- Legacy output overview.latest_date: 2026-11-05 [legacy_metrics]
- Legacy output trend_health.trend_strength: bearish [legacy_metrics]
- Legacy output volatility_health.risk_level: medium [legacy_metrics]
- Legacy output consensus_health.agreement_level: medium [legacy_metrics]
- Legacy output overall_health.grade: D [legacy_metrics]

### Proposed analysis

The historical reconstruction-based diagnostic is bearish on trend but mixed on momentum.
- The Graph returned 180 closed daily token-level price observations and the legacy run used 179 adjacent returns. The dated series covers 2026-05-10 through 2026-11-05; the source fetch date was 2026-11-06. A separate gap-interval count was not supplied. The series is useful historical context, but it is not a selected-pool candle history or independent proof of market-wide prices. [evidence: graph_token_daily, graph_source_manifest, legacy_metrics; inputs: graph-token-history, graph_token_daily_price_usd, graph_token_daily_returns, legacy_vae_specific_metrics_data_points]
- For 2026-11-05, the legacy diagnostic reports trend score 0.0 and trend strength bearish, with overall score 58.20904860722494 and grade D. Its counterpoint is momentum score 70.0 and bullish MACD ratio 0.86. These are original scores and ratios calculated on reconstructions, not independent forecasts or a current trading signal. The legacy metrics fetch date was 2026-11-06. [evidence: legacy_metrics; inputs: legacy-overview-latest_date, legacy_trend_health_score, legacy-trend_health-trend_strength, legacy_overall_health_score, legacy-overall_health-grade, legacy_momentum_health_score, legacy_momentum_health_bullish_macd_ratio]
- Limitation: The diagnostic is historical, reconstruction-based and unapproved; model calibration is not established.
- Limitation: The provider history is not independently verified and does not describe the selected pool specifically.
- Follow-up: Do independently verified current price data and a fresh, reproducible calculation support the historical trend assessment?
- Graph token-level data is not selected-pool history; source correctness and history adequacy remain open.
- Original legacy metrics use 50 reconstructions; model calibration is not independently verified.

## Proposed conclusion

As a proposed research judgment, defer new exposure to this Ethereum token until current contract authority and an executable route are checked. This is not a finding of fraud or a universal sell restriction.

Proposed action: Defer new exposure; obtain current block-specific contract checks and size-specific route quotes before deciding. Do not interpret this as a recommendation to prevent an existing holder from exiting.

The reported administrative capabilities could affect transfers or supply if confirmed, and the selected pool’s 120777.01 USD reported liquidity is not an executable quote. Both observations are historical, with fetch dates of 2026-11-06 and no supplied observation times. [evidence: security, market; inputs: provider-transfer_pausable, provider-is_mintable, liquidity_usd_rounded]
- Counterevidence: GoPlus reported is_honeypot = 0 and sell_tax = 0; DEX Screener reported 35 sells in the selected pool’s rolling 24-hour window. These observations weigh against alleging a universal restriction, but do not test the intended holder and trade. [security, market]
- Would change this view: Reconsider deferral if recent block-specific code and state checks establish the relevant pause and mint authorities and their status, and coherent buy-and-sell simulations plus executable quotes show acceptable execution for the intended holder, size and route.
- Would change this view: Tighten the recommendation if a current, reproducible check finds an active transfer restriction or materially worse execution for the intended route.
