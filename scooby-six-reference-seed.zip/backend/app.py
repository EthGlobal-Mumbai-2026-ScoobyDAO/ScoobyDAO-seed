import base64, datetime, hashlib, hmac, json, os, shutil, subprocess, sys, tempfile
from urllib.parse import urlsplit
from pathlib import Path
from typing import Literal
from fastapi import FastAPI, HTTPException, Header, Depends
from publication.deps import get_world_optional
from fastapi.responses import Response
from urllib.parse import quote
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from jsonschema import Draft202012Validator
from store import ROOT, DATA, db, ident, now, dumps, digest, row, job, event, PILLARS
from worker import wake
app=FastAPI(title='Scooby DAO local operator API',version='0.1.0',description='Local-only prototype. Local review receipts are unauthenticated; World ID integration requires live verification.')
web_origin=os.getenv('SCOOBY_WEB_ORIGIN','').strip()
if web_origin:
 if not (web_origin.startswith('http://') or web_origin.startswith('https://')) or '*' in web_origin or web_origin.endswith('/'):
  raise ValueError('SCOOBY_WEB_ORIGIN must be one explicit origin without trailing slash')
 app.add_middleware(CORSMiddleware,allow_origins=[web_origin],allow_credentials=False,allow_methods=['GET'],allow_headers=['Content-Type'])
def err(code,msg): raise HTTPException(code,msg)
def getrow(c,sql,args):
 r=c.execute(sql,args).fetchone()
 if not r: err(404,'Not found')
 return r
def key(k):
 if not k or len(k)>200: err(400,'Idempotency-Key required (maximum 200 characters)')
 return k
def signal():
 try: wake()
 except Exception: pass # persisted queue is reconciled by worker
class Candidate(BaseModel): payload: dict
class Selection(BaseModel):
 kind: Literal['qualified','diagnostic_exception','defer']
 actor: str = Field(min_length=1,max_length=100)
 reason: str = Field(min_length=1,max_length=1000)
class Run(BaseModel): candidate_id: str; selection_id: str
class ImportReport(BaseModel): run_id: str; bundle_path: str
class Review(BaseModel):
 decision: Literal['request','approve','revise','reject']
 actor: str = Field(min_length=1,max_length=100)
 reason: str = Field(min_length=1,max_length=1000)
 sha256: str = Field(pattern=r'^[0-9a-f]{64}$')
@app.get('/health')
def health(): return {'status':'ok','scope':'local operator only','production_authentication':False}
@app.get('/status')
def status():
 with db() as c:
  counts={x['state']:x['n'] for x in c.execute('SELECT state,count(*) n FROM jobs GROUP BY state')}
  hb=row(c.execute("SELECT * FROM heartbeats WHERE name='worker'").fetchone())
 return {'queue':counts,'worker':hb,'worker_fresh':bool(hb and now()-hb['seen']<150),'scheduler':'Huey periodic reconciliation; no discovery sources configured','feeds':[],'budget':{'call_limit':int(os.getenv('SCOOBY_MODEL_CALL_BUDGET','0')),'usage_accounting':'per-call response when available; token-spend and rate limits not implemented'}}
@app.get('/schemas')
def schemas():
 return [{'file':p.name,'sha256':digest(p.read_bytes()),'schema':json.loads(p.read_text(encoding='utf-8-sig'))} for p in sorted((ROOT/'schemas').glob('*.schema.json'))]
@app.post('/candidates')
def candidate(x:Candidate):
 try: Draft202012Validator(json.loads((ROOT/'schemas/candidate.schema.json').read_text(encoding='utf-8-sig'))).validate(x.payload)
 except Exception as e: err(422,'Candidate fails frozen schema: '+str(e).splitlines()[0])
 p=x.payload; cid=p.get('candidate_id')
 if not cid: err(422,'candidate_id missing')
 with db() as c:
  old=c.execute('SELECT payload FROM candidates WHERE id=?',(cid,)).fetchone()
  if old and old[0]!=dumps(p): err(409,'Candidate ID exists with different content')
  c.execute('INSERT OR IGNORE INTO candidates VALUES(?,?,?)',(cid,dumps(p),now()))
 return {'candidate_id':cid,'gate':'unknown','monitoring':True}
@app.get('/candidates')
def candidates():
 with db() as c: return [{'candidate_id':x['id'],'gate':'unknown','monitoring':True} for x in c.execute('SELECT * FROM candidates')]
@app.get('/diagnostics')
def diagnostics():
 with db() as c:
  result=[]
  for x in c.execute('SELECT * FROM diagnostic_shortlist ORDER BY rowid'):
   attempt=c.execute('SELECT * FROM diagnostic_attempts WHERE candidate_id=?',(x['candidate_id'],)).fetchone()
   installed=c.execute('SELECT r.id,r.version,r.sha256 FROM reports r JOIN diagnostic_imports d ON d.run_id=r.run_id WHERE d.candidate_id=?',(x['candidate_id'],)).fetchone()
   reference=c.execute("SELECT r.id,r.version,r.sha256 FROM reports r JOIN investigations i ON i.id=r.run_id WHERE i.candidate_id=? AND i.status='reference_only' AND NOT EXISTS (SELECT 1 FROM diagnostic_imports d WHERE d.run_id=i.id) ORDER BY r.created DESC LIMIT 1",(x['candidate_id'],)).fetchone()
   result.append(dict(row(x),attempt=row(attempt),report=row(installed),reference=dict(row(reference),provenance='source_curated_reference') if reference else None,case_admitted=False,world_verified=False,provenance='user_requested_historical_diagnostic'))
  return result
@app.get('/candidates/{candidate_id}')
def candidate_detail(candidate_id:str):
 with db() as c: r=getrow(c,'SELECT * FROM candidates WHERE id=?',(candidate_id,))
 return {'candidate':json.loads(r['payload']),'gate':'unknown','reason':'Concern verifiers are not installed; no candidate is qualified.'}
@app.post('/candidates/{candidate_id}/selection')
def select(candidate_id:str,x:Selection,idempotency_key:str=Header(None)):
 k=key(idempotency_key)
 with db() as c:
  getrow(c,'SELECT id FROM candidates WHERE id=?',(candidate_id,))
  old=c.execute('SELECT * FROM selections WHERE idem=?',(k,)).fetchone()
  if old:
   if (old['candidate_id'],old['kind'],old['actor'],old['reason'])!=(candidate_id,x.kind,x.actor,x.reason): err(409,'Idempotency key conflict')
   return row(old)
  if x.kind=='qualified': err(409,'No verified gate implementation configured')
  i=ident(); c.execute('INSERT INTO selections VALUES(?,?,?,?,?,?,?)',(i,candidate_id,x.kind,x.actor,x.reason,now(),k))
  return row(getrow(c,'SELECT * FROM selections WHERE id=?',(i,)))
@app.post('/investigations')
def investigate(x:Run,idempotency_key:str=Header(None)):
 k=key(idempotency_key)
 with db() as c:
  old=c.execute('SELECT * FROM investigations WHERE idem=?',(k,)).fetchone()
  if old:
   if (old['candidate_id'],old['selection_id'])!=(x.candidate_id,x.selection_id): err(409,'Idempotency key conflict')
   return row(old)
  s=getrow(c,'SELECT * FROM selections WHERE id=?',(x.selection_id,))
  if s['candidate_id']!=x.candidate_id or s['kind'] not in ('qualified','diagnostic_exception'): err(409,'Selection does not authorize this investigation')
  candidate_row=getrow(c,'SELECT payload FROM candidates WHERE id=?',(x.candidate_id,))
  if json.loads(candidate_row['payload']).get('mode')=='live': err(403,'Live research requires a policy decision or a verified human authorization; legacy selection is unverified')
  i=ident(); c.execute('INSERT INTO investigations VALUES(?,?,?,?,?,?)',(i,x.candidate_id,x.selection_id,'queued',now(),k))
  for p in PILLARS: c.execute('INSERT INTO pillars VALUES(?,?,?,?)',(i,p,'queued','Awaiting worker'))
  event(c,i,'created','Local operator selection; human identity not authenticated'); job(c,'investigate',i,'investigate:'+i)
 signal(); return {'id':i,'status':'queued'}
@app.post('/reference-runs')
def reference_run(x:Run,idempotency_key:str=Header(None)):
 """A no-research container for separately authorized, manually imported reference reports."""
 k=key(idempotency_key)
 with db() as c:
  c.execute('BEGIN IMMEDIATE');old=c.execute('SELECT * FROM investigations WHERE idem=?',(k,)).fetchone()
  if old:
   if (old['candidate_id'],old['selection_id'],old['status'])!=(x.candidate_id,x.selection_id,'reference_only'):err(409,'Idempotency key conflict')
   return {'id':old['id'],'status':'reference_only'}
  selection=getrow(c,'SELECT * FROM selections WHERE id=?',(x.selection_id,))
  if selection['candidate_id']!=x.candidate_id or selection['kind']!='diagnostic_exception':err(409,'Scoped reference selection required')
  run=ident();c.execute('INSERT INTO investigations VALUES(?,?,?,?,?,?)',(run,x.candidate_id,x.selection_id,'reference_only',now(),k))
  for pillar in PILLARS:c.execute('INSERT INTO pillars VALUES(?,?,?,?)',(run,pillar,'unavailable','Reference import only; no research authorized or performed.'))
  event(c,run,'reference_only','Local source-curated report import only; no research job or authenticated approval')
  return {'id':run,'status':'reference_only'}
@app.get('/investigations/{run_id}')
def run(run_id:str):
 with db() as c:
  r=row(getrow(c,'SELECT * FROM investigations WHERE id=?',(run_id,))); r['pillars']=[row(x) for x in c.execute('SELECT * FROM pillars WHERE run_id=?',(run_id,))]; decision=c.execute('SELECT id FROM case_decisions WHERE run_id=?',(run_id,)).fetchone();r['graph_source']=__import__('case_graph').summary(c,decision['id']) if decision else None;return r
@app.get('/investigations/{run_id}/events')
def events(run_id:str):
 with db() as c:
  getrow(c,'SELECT id FROM investigations WHERE id=?',(run_id,)); return [row(x) for x in c.execute('SELECT * FROM events WHERE run_id=? ORDER BY seq',(run_id,))]
@app.post('/investigations/{run_id}/cancel')
def cancel(run_id:str):
 with db() as c:
  getrow(c,'SELECT id FROM investigations WHERE id=?',(run_id,)); c.execute("UPDATE investigations SET status='cancelled' WHERE id=?",(run_id,)); c.execute("UPDATE jobs SET state='cancelled' WHERE kind='investigate' AND ref=? AND state='queued'",(run_id,)); event(c,run_id,'cancelled','Local operator')
 return {'status':'cancelled'}
@app.post('/investigations/{run_id}/resume')
def resume(run_id:str,idempotency_key:str=Header(None)):
 k=key(idempotency_key)
 with db() as c:
  c.execute('BEGIN IMMEDIATE')
  r=getrow(c,'SELECT * FROM investigations WHERE id=?',(run_id,))
  old=c.execute('SELECT * FROM jobs WHERE idem=?',(k,)).fetchone()
  if old:
   if old['kind']!='investigate' or old['ref']!=run_id: err(409,'Idempotency key conflict')
   return {'job_id':old['id']}
  candidate_row=getrow(c,'SELECT payload FROM candidates WHERE id=?',(r['candidate_id'],));decision=c.execute('SELECT * FROM case_decisions WHERE run_id=?',(run_id,)).fetchone()
  if decision:
   if r['status'] not in ('blocked','failed'):err(409,'Case run is not retryable')
   snap=getrow(c,'SELECT * FROM case_snapshots WHERE id=?',(decision['snapshot_id'],));case=getrow(c,'SELECT * FROM cases WHERE id=?',(decision['case_id'],))
   if snap['expires']<=now() or case['current_snapshot']!=snap['id'] or snap['policy_digest']!=case_policy_digest():err(409,'Authorization expired or superseded; new authorization required')
  else:
   if json.loads(candidate_row['payload']).get('mode')=='live': err(403,'Live resumption requires a fresh authorized case decision')
   if r['status'] not in ('incomplete','cancelled'): err(409,'Run is not resumable')
  c.execute("UPDATE investigations SET status='queued' WHERE id=?",(run_id,)); c.execute("UPDATE pillars SET status='queued' WHERE run_id=? AND status IN ('unavailable','failed')",(run_id,)); event(c,run_id,'resumed','Retry under existing case authorization and budget' if decision else 'Local operator'); j=job(c,'investigate',run_id,k)
 signal(); return {'job_id':j}
@app.post('/scans')
def scan(idempotency_key:str=Header(None)):
 with db() as c: j=job(c,'scan','bounded-empty',key(idempotency_key))
 signal(); return {'job_id':j,'coverage':'unknown'}
@app.get('/jobs/{job_id}')
def jobs(job_id:str):
 with db() as c: return row(getrow(c,'SELECT * FROM jobs WHERE id=?',(job_id,)))
@app.post('/reports/import')
def import_report(x:ImportReport):
 frontend=os.getenv('SCOOBY_FRONTEND_DIR', str(ROOT/'vendor'/'reader'))
 if not frontend: err(503,'SCOOBY_FRONTEND_DIR is not configured')
 source=Path(x.bundle_path).resolve()
 if not source.is_dir() or not (source/'report.json').is_file(): err(400,'Bundle directory missing report.json')
 if any(p.is_symlink() for p in source.rglob('*')): err(400,'Symlinks forbidden')
 with tempfile.TemporaryDirectory(dir=DATA) as tmp:
  # Work from a snapshot; validation and persistence consume identical bytes.
  snap=Path(tmp)/'bundle'; shutil.copytree(source,snap)
  try: subprocess.run([sys.executable,str(Path(frontend)/'build.py'),str(snap/'report.json'),str(Path(tmp)/'validated')],check=True,timeout=120,capture_output=True)
  except Exception: err(422,'Frontend contract validation failed; inspect bundle and adapter')
  raw=(snap/'report.json').read_bytes(); d=json.loads(raw); sha=digest(raw)
  with db() as c:
   run=getrow(c,'SELECT * FROM investigations WHERE id=?',(x.run_id,))
   if d['candidate_id']!=run['candidate_id']: err(409,'Report candidate differs from selected run')
   old=c.execute('SELECT * FROM reports WHERE id=? AND version=?',(d['report_id'],d['report_version'])).fetchone()
   if old:
    if old['sha256']!=sha or old['run_id']!=x.run_id: err(409,'Immutable report version already exists')
    return row(old)
   target=DATA/'bundles'/sha; target.parent.mkdir(exist_ok=True)
   if not target.exists():
    try: os.rename(snap,target)
    except OSError:
     if not target.exists(): raise
   # Revalidate the installed bytes, including crash recovery or concurrent imports.
   try: subprocess.run([sys.executable,str(Path(frontend)/'build.py'),str(target/'report.json'),str(Path(tmp)/'installed-check')],check=True,timeout=120,capture_output=True)
   except Exception: err(409,'Installed bundle integrity failure')
   if digest((target/'report.json').read_bytes())!=sha: err(409,'Installed report digest mismatch')
   c.execute('INSERT INTO reports VALUES(?,?,?,?,?,?)',(d['report_id'],d['report_version'],x.run_id,sha,str(target),now()))
   event(c,x.run_id,'report_imported',sha)
   return {'report_id':d['report_id'],'version':d['report_version'],'sha256':sha,'review':'pending'}
def report_metadata(c,r):
 run=getrow(c,'SELECT * FROM investigations WHERE id=?',(r['run_id'],))
 selection=getrow(c,'SELECT * FROM selections WHERE id=?',(run['selection_id'],))
 path=Path(r['path'])/'report.json'
 if path.is_symlink() or not path.is_file(): err(409,'Stored report integrity failure')
 raw=path.read_bytes()
 if digest(raw)!=r['sha256']: err(409,'Stored report integrity failure')
 doc=json.loads(raw)
 latest=c.execute('SELECT decision,created FROM reviews WHERE report_id=? AND version=? ORDER BY created DESC',(r['id'],r['version'])).fetchone()
 case_decision=c.execute('SELECT id,action,case_id FROM case_decisions WHERE run_id=?',(run['id'],)).fetchone()
 diagnostic=c.execute('SELECT * FROM diagnostic_imports WHERE run_id=?',(run['id'],)).fetchone()
 admission_auth='world_id' if case_decision and case_decision['action']=='human_research' else 'policy_engine' if case_decision else 'unverified local operator'
 return {'metadata_status':'available','integrity':'verified','report_id':r['id'],'report_version':r['version'],'run_id':run['id'],'run_status':run['status'],'candidate_id':run['candidate_id'],'report_sha256':r['sha256'],
         'graph_source':__import__('case_graph').summary(c,case_decision['id']) if case_decision else None,'mode':doc.get('mode'),'provenance':'user_requested_historical_diagnostic' if diagnostic else 'source_curated_reference' if run['status']=='reference_only' else 'case_investigation' if case_decision else 'imported','diagnostic':{'description':diagnostic['description'],'model_status':diagnostic['model_status'],'case_admitted':False,'world_verified':False} if diagnostic else None,'case_id':case_decision['case_id'] if case_decision else None,'identity':doc.get('identity'),'observation_times':sorted({e['observed_at'] for e in doc.get('evidence',[]) if e.get('observed_at')}),'fetch_times':sorted({e['fetched_at'] for e in doc.get('evidence',[]) if e.get('fetched_at')}),'pillars':{name:{'status':pillar['status'],'quality_issues':pillar.get('quality_issues',[])} for name,pillar in doc.get('pillars',{}).items()},'release':{'status':'unavailable','consumer_visible':None,'reason':'Admin review and release authorization are not implemented in this case workflow.'},
         'selection':{'kind':selection['kind'],'reason':selection['reason'],'admission_qualified':False if selection['kind']=='diagnostic_exception' else None,'authentication':admission_auth},
         'review':{'status':latest['decision'] if latest else 'pending','authentication':'unverified local operator'},'created':r['created']}
def unavailable_report_metadata(c,r):
 # Preserve only indexed identifiers; never infer identity, coverage or review from unreadable bytes.
 run=c.execute('SELECT id,candidate_id,status FROM investigations WHERE id=?',(r['run_id'],)).fetchone()
 decision=c.execute('SELECT case_id FROM case_decisions WHERE run_id=?',(r['run_id'],)).fetchone()
 return {'metadata_status':'unavailable','integrity':'unavailable','reason':'report_integrity_unavailable','report_id':r['id'],'report_version':r['version'],'run_id':r['run_id'],'run_status':run['status'] if run else None,'candidate_id':run['candidate_id'] if run else None,'case_id':decision['case_id'] if decision else None,'report_sha256':r['sha256'],'identity':None,'mode':None,'provenance':'unavailable','observation_times':[],'fetch_times':[],'pillars':None,'graph_source':None,'selection':None,'review':{'status':'unknown','authentication':'unavailable'},'release':{'status':'unavailable','consumer_visible':None,'reason':'Stored report cannot be verified.'},'created':r['created']}
@app.get('/reports')
def list_reports():
 # Public listings expose only separately approved and released reports.
 with db() as c:
  items=[]
  for r in c.execute('SELECT * FROM reports ORDER BY created DESC,id ASC,version ASC').fetchall():
   if not report_review.consumer_visible(c,r['id'],r['version']): continue
   try: items.append(dict(report_metadata(c,r),admin_review=report_review.public_status(c,r['id'],r['version'])))
   except (HTTPException,OSError,ValueError,KeyError,TypeError,UnicodeError): items.append(unavailable_report_metadata(c,r))
  return items
@app.get('/reports/{report_id}/{version}/artifacts')
def report_artifacts(report_id:str,version:str):
 with db() as c:
  getrow(c,'SELECT id FROM reports WHERE id=? AND version=?',(report_id,version))
  if not report_review.consumer_visible(c,report_id,version): err(404,'Not found')
 return artifact_listing(report_id,version,lambda job_id,name:f'/artifacts/{job_id}/{name}',lambda sha:'/packages/'+sha)
def latest_render(c,report_id,version,sha256):
 jobs=c.execute("SELECT * FROM jobs WHERE kind='render' AND state='done' ORDER BY created DESC").fetchall()
 return next((j for j in jobs if json.loads(j['ref'])=={'id':report_id,'version':version,'sha256':sha256}),None)
def artifact_listing(report_id,version,file_url,package_url):
 with db() as c:
  r=getrow(c,'SELECT * FROM reports WHERE id=? AND version=?',(report_id,version))
  result=report_metadata(c,r); result['admin_review']=report_review.public_status(c,report_id,version)
  jobs=c.execute("SELECT * FROM jobs WHERE kind='render' ORDER BY created DESC").fetchall()
  matching=[j for j in jobs if json.loads(j['ref'])=={'id':report_id,'version':version,'sha256':r['sha256']}]
  match=next((j for j in matching if j['state']=='done'),None);latest=matching[0] if matching else None

 if not match:
  result['artifacts']={k:{'availability':'unavailable','sha256':None,'url':None} for k in ('html','markdown','pdf')}; result['render_status']=({'queued':'queued','running':'rendering','failed':'failed','cancelled':'cancelled'}.get(latest['state'],'not_rendered') if latest else 'not_rendered'); result['package']={'availability':'unavailable','package_sha256':None,'url':None}; return result
 out=DATA/'artifacts'/match['id']; manifest_path=out/'manifest.json'
 if not manifest_path.is_file(): err(409,'Render manifest missing')
 with db() as c: locked=c.execute('SELECT sha256 FROM render_manifests WHERE job_id=?',(match['id'],)).fetchone()
 if manifest_path.is_symlink(): err(409,'Render manifest integrity failure')
 manifest_raw=manifest_path.read_bytes()
 if not locked or digest(manifest_raw)!=locked['sha256']: err(409,'Render manifest integrity failure')
 m=json.loads(manifest_raw)
 if (m.get('report_id'),m.get('report_version'),m.get('report_sha256'))!=(report_id,version,r['sha256']): err(409,'Render manifest identity mismatch')
 result['render_status']='pending_review_draft'; result['artifacts']={}
 result['package']={'availability':'available','package_sha256':locked['sha256'],'url':package_url(locked['sha256'])}
 for kind,name,keyname in [('html','index.html','html_sha256'),('markdown','report.md','markdown_sha256'),('pdf','report.pdf','pdf_sha256')]:
  expected=m.get(keyname); f=out/name
  if expected and (not f.is_file() or digest(f.read_bytes())!=expected): err(409,'Render artifact integrity failure')
  result['artifacts'][kind]={'availability':'available' if expected else 'unavailable','sha256':expected,'url':file_url(match['id'],name) if expected else None,'report_sha256':r['sha256']}
 return result
@app.get('/reports/{report_id}/{version}')
def report(report_id:str,version:str):
 with db() as c:
  r=row(getrow(c,'SELECT id,version,run_id,sha256,created FROM reports WHERE id=? AND version=?',(report_id,version)))
  r['reviews']=[row(x) for x in c.execute('SELECT id,sha256,decision,actor,reason,created FROM reviews WHERE report_id=? AND version=? ORDER BY created',(report_id,version))];full=getrow(c,'SELECT * FROM reports WHERE id=? AND version=?',(report_id,version));r['metadata']=report_metadata(c,full);return r
@app.post('/reports/{report_id}/{version}/review')
def review(report_id:str,version:str,x:Review,idempotency_key:str=Header(None)):
 k=key(idempotency_key)
 with db() as c:
  r=getrow(c,'SELECT * FROM reports WHERE id=? AND version=?',(report_id,version))
  if r['sha256']!=x.sha256: err(409,'Digest does not match immutable version')
  old=c.execute('SELECT * FROM reviews WHERE idem=?',(k,)).fetchone()
  if old:
   if (old['report_id'],old['version'],old['sha256'],old['decision'],old['actor'],old['reason'])!=(report_id,version,x.sha256,x.decision,x.actor,x.reason): err(409,'Idempotency key conflict')
   return row(old)
  i=ident(); c.execute('INSERT INTO reviews VALUES(?,?,?,?,?,?,?,?,?)',(i,report_id,version,x.sha256,x.decision,x.actor,x.reason,now(),k)); return {'id':i,'sha256':x.sha256,'decision':x.decision,'authentication':'unverified local operator'}
@app.post('/reports/{report_id}/{version}/render')
def render(report_id:str,version:str,idempotency_key:str=Header(None)):
 with db() as c:
  r=getrow(c,'SELECT * FROM reports WHERE id=? AND version=?',(report_id,version)); ref=dumps({'id':report_id,'version':version,'sha256':r['sha256']}); j=job(c,'render',ref,key(idempotency_key))
 signal(); return {'job_id':j,'status':'pending review draft','pdf':'attempted when SCOOBY_BROWSER is configured'}
def checked_bytes(path,expected):
 if path.is_symlink() or not path.is_file(): err(404,'Artifact missing')
 raw=path.read_bytes()
 if not expected or digest(raw)!=expected: err(409,'Artifact integrity failure')
 return raw
def artifact_headers():
 return {'X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:"}
def safe_asset(base,asset_path):
 if not asset_path or any(x in asset_path for x in ('\\',':','%','?','#')) or any(x in ('','.','..') for x in asset_path.split('/')): err(400,'Unsafe asset path')
 path=base
 for part in asset_path.split('/'):
  path=path/part
  if path.is_symlink(): err(400,'Symlink forbidden')
 if not path.resolve().is_relative_to(base.resolve()): err(400,'Unsafe asset path')
 return path
def report_assets(doc):
 allowed={}
 for x in doc['evidence']+[a for a in doc['artifacts'] if a['availability']=='available']:
  name=x['path']; sha=x['sha256']
  if name in allowed and allowed[name]!=sha: err(409,'Conflicting asset hashes')
  allowed[name]=sha
 return allowed
def visible_or_404(report_id,version,what):
 with db() as c:
  if not report_review.consumer_visible(c,report_id,version): err(404,what+' not found')
def package_context(package_sha256,public=True):
 import re
 if not re.fullmatch('[0-9a-f]{64}',package_sha256): err(404,'Package not found')
 with db() as c:
  j=c.execute("SELECT jobs.* FROM jobs JOIN render_manifests ON jobs.id=render_manifests.job_id WHERE render_manifests.sha256=? AND jobs.state='done' AND jobs.kind='render' LIMIT 1",(package_sha256,)).fetchone()
  if not j: err(404,'Package not found')
 out=DATA/'artifacts'/j['id']; ref=json.loads(j['ref'])
 if public: visible_or_404(ref['id'],ref['version'],'Package')
 manifest=json.loads(checked_bytes(out/'manifest.json',package_sha256))
 if (manifest.get('report_id'),manifest.get('report_version'),manifest.get('report_sha256'))!=(ref['id'],ref['version'],ref['sha256']): err(409,'Package identity mismatch')
 raw=checked_bytes(out/'report.json',ref['sha256']); doc=json.loads(raw)
 if (doc['report_id'],doc['report_version'])!=(ref['id'],ref['version']): err(409,'Report identity mismatch')
 return out,ref,manifest,raw,doc
@app.get('/packages/{package_sha256}')
def package_descriptor(package_sha256:str):
 out,ref,m,raw,doc=package_context(package_sha256); report_assets(doc)
 prefix='/packages/'+package_sha256
 def asset_url(path): return prefix+'/assets/'+quote(path,safe='/') if path else None
 artifacts=[{'kind':a['kind'],'path':a['path'],'availability':a['availability'],'media_type':a['media_type'],'sha256':a['sha256'],'url':asset_url(a['path']) if a['availability']=='available' else None} for a in doc['artifacts']]
 evidence=[{'id':e['id'],'path':e['path'],'availability':'available','media_type':'application/octet-stream','sha256':e['sha256'],'url':asset_url(e['path'])} for e in doc['evidence']]
 return {'package_sha256':package_sha256,'candidate_id':doc['candidate_id'],'report_id':ref['id'],'report_version':ref['version'],'report_sha256':ref['sha256'],'report_review_snapshot':{'status':doc['review']['status'],'authentication':'unverified report assertion'},'manifest':{'media_type':'application/json','sha256':package_sha256,'url':prefix+'/manifest.json'},'report':{'availability':'available','media_type':'application/json','sha256':ref['sha256'],'url':prefix+'/report.json'},'artifacts':artifacts,'evidence':evidence}
@app.get('/packages/{package_sha256}/manifest.json')
def package_manifest(package_sha256:str):
 out,ref,m,raw,doc=package_context(package_sha256)
 data=checked_bytes(out/'manifest.json',package_sha256)
 return Response(content=data,media_type='application/json',headers=artifact_headers())
@app.get('/packages/{package_sha256}/report.json')
def package_report(package_sha256:str):
 out,ref,m,raw,doc=package_context(package_sha256)
 return Response(content=raw,media_type='application/json',headers=artifact_headers())
@app.get('/packages/{package_sha256}/assets/{asset_path:path}')
def package_asset(package_sha256:str,asset_path:str):
 return package_asset_bytes(package_sha256,asset_path,public=True)
def package_asset_bytes(package_sha256,asset_path,public):
 out,ref,m,raw,doc=package_context(package_sha256,public); allowed=report_assets(doc)
 path=safe_asset(out/'assets',asset_path)
 if asset_path not in allowed: err(404,'Asset not found')
 data=checked_bytes(path,allowed[asset_path])
 media=next((a['media_type'] for a in doc['artifacts'] if a['availability']=='available' and a['path']==asset_path),None)
 return Response(content=data,media_type=media or 'application/octet-stream',headers=artifact_headers())
@app.get('/artifacts/{job_id}/{name}')
def artifact(job_id:str,name:str):
 return artifact_bytes(job_id,name,public=True)
def artifact_bytes(job_id,name,public):
 if name not in ('index.html','report.json','report.md','report.pdf','manifest.json'): err(404,'Artifact unavailable')
 with db() as c:
  j=getrow(c,'SELECT * FROM jobs WHERE id=?',(job_id,))
  if j['kind']!='render' or j['state']!='done': err(409,'Artifact not ready')
  locked=getrow(c,'SELECT sha256 FROM render_manifests WHERE job_id=?',(job_id,))
 out=DATA/'artifacts'/job_id; ref=json.loads(j['ref'])
 if public: visible_or_404(ref['id'],ref['version'],'Artifact')
 manifest_raw=checked_bytes(out/'manifest.json',locked['sha256']); m=json.loads(manifest_raw)
 if (m.get('report_id'),m.get('report_version'),m.get('report_sha256'))!=(ref['id'],ref['version'],ref['sha256']): err(409,'Render manifest identity mismatch')
 if name=='manifest.json': data=manifest_raw
 elif name=='report.json': data=checked_bytes(out/name,ref['sha256'])
 else: data=checked_bytes(out/name,m.get({'index.html':'html_sha256','report.md':'markdown_sha256','report.pdf':'pdf_sha256'}[name]))
 media={'index.html':'text/html','report.json':'application/json','manifest.json':'application/json','report.md':'text/markdown','report.pdf':'application/pdf'}[name]
 return Response(content=data,media_type=media,headers=artifact_headers())
@app.get('/artifacts/{job_id}/assets/{asset_path:path}')
def artifact_asset(job_id:str,asset_path:str):
 with db() as c:
  j=getrow(c,'SELECT * FROM jobs WHERE id=?',(job_id,))
  if j['kind']!='render' or j['state']!='done': err(409,'Artifact not ready')
  locked=getrow(c,'SELECT sha256 FROM render_manifests WHERE job_id=?',(job_id,))
 return package_asset_bytes(locked['sha256'],asset_path,public=True)

class ReasonInput(BaseModel):
 pillar: Literal['microstructure','onchain','fundamentals','statistical_risk','technical_health']
 evidence: list[dict] = Field(min_length=1,max_length=20)
@app.post('/investigations/{run_id}/reason')
def queue_reason(run_id:str,x:ReasonInput,idempotency_key:str=Header(None)):
 k=key(idempotency_key)
 if len(dumps(x.evidence))>30000 or any(not isinstance(e.get('id'),str) or not e['id'] for e in x.evidence): err(422,'Bounded evidence with IDs required')
 if len({e['id'] for e in x.evidence})!=len(x.evidence): err(422,'Evidence IDs must be unique')
 if int(os.getenv('SCOOBY_MODEL_CALL_BUDGET','0'))<=0: err(503,'Model call budget is zero')
 with db() as c:
  run=getrow(c,'SELECT * FROM investigations WHERE id=?',(run_id,))
  if run['status']=='cancelled': err(409,'Run cancelled')
  source=getrow(c,'SELECT payload FROM candidates WHERE id=?',(run['candidate_id'],))
  if json.loads(source['payload']).get('mode')=='live': err(403,'Live reasoning requires a bound, authorized evidence adapter')
  old=c.execute('SELECT * FROM jobs WHERE idem=?',(k,)).fetchone()
  if old:
   inp=c.execute('SELECT * FROM reasoning_inputs WHERE id=?',(old['ref'],)).fetchone()
   if old['kind']!='reason' or not inp or (inp['run_id'],inp['pillar'],inp['evidence'])!=(run_id,x.pillar,dumps(x.evidence)): err(409,'Idempotency key conflict')
   return {'job_id':old['id'],'input_id':inp['id']}
  i=ident(); c.execute('INSERT INTO reasoning_inputs VALUES(?,?,?,?,?,?,?)',(i,run_id,x.pillar,dumps(x.evidence),None,'queued',now())); j=job(c,'reason',i,k)
 signal(); return {'job_id':j,'input_id':i,'coverage':'operator-supplied, unverified'}
@app.get('/reasoning/{input_id}')
def get_reason(input_id:str):
 with db() as c:
  x=row(getrow(c,'SELECT * FROM reasoning_inputs WHERE id=?',(input_id,)))
  x['evidence']=json.loads(x['evidence']); x['output']=json.loads(x['output']) if x['output'] else None
  return x

@app.get('/readiness/honeypot', tags=['readiness'])
def honeypot_readiness():
 return {
  'kind':'static_integration_inventory',
  'checkpoint_case_status':'no_fresh_milestone_selection_recorded_in_this_checkpoint',
  'reference_track':'RAY source-curated report imported; diagnostic exception, not gate-qualified; review pending',
  'normal_gate':{'required_distinct_verified_groups':4,'wired_verifiers':0,'qualified_selection_enabled':False},
  'discovery_newer_work':'G07 and partial G09 exist in discovery work; neither is wired to this worker',
  'investigation':'five persisted pillar states; producers are not wired',
  'research_output':'reference bundle imported and rendered; no automated end-to-end deep research',
  'reader':'corrected IRC reader integrated for imported bundles; automated research remains unwired',
  'pdf':'reference draft contains expanded reader and bound full Markdown; thumbnail and text checks passed, detailed accessibility and typography QA pending',
  'review':'local receipts are unauthenticated; separate World ID integration is not live-verified',
  'publication':'optional World ID and outbox implementation; disabled by default, not live-verified',
  'paid_model_budget_default':0,
  'documentation':'docs/honeypot-readiness.md'
 }

# Publication boundary and World ID Agent Pass sign-off live in publication/ (see docs/publication-plan.md).
from publication import routes as publication_routes, web_adapter as publication_web
app.include_router(publication_routes.router)
app.include_router(publication_web.router)

# Admin boundary for the two World ID checkpoints (docs/admin-world-checkpoints.md): the /web/v1/admin API, the
# path guard on case-checkpoint routes, and CORS that lets the admin web send its session bearer token.
from publication import admin as publication_admin, admin_routes as publication_admin_routes, review as report_review
app.include_router(publication_admin_routes.router)
app.add_middleware(publication_admin.AdminRouteGuard)

# Subject-matter-expert view of the full rendered report before release (any installed version). Needs an admin
# session with report_review. Bytes come only from the newest completed render of exactly the installed report bytes.
from publication.deps import require_admin as _require_admin

@app.get('/scouting/cases/{case_id}/reference-reports')
def case_reference_reports(case_id: str, principal=Depends(_require_admin('report_review'))):
 with db() as c:
  case=c.execute('SELECT candidate_id FROM cases WHERE id=?',(case_id,)).fetchone()
  if not case: err(404,'Case not found')
  reports=c.execute('SELECT r.* FROM case_reference_reports l JOIN reports r ON r.id=l.report_id AND r.version=l.version JOIN investigations i ON i.id=r.run_id WHERE l.case_id=? AND i.candidate_id=? AND i.status=? ORDER BY r.created DESC',(case_id,case['candidate_id'],'reference_only')).fetchall()
  return {'case_id':case_id,'candidate_id':case['candidate_id'],'association':'local_reference_only','gate_effect':'none','reports':[report_metadata(c,r) for r in reports]}
SME_FILES=('index.html','report.json','report.md','report.pdf','manifest.json')
def sme_render_job(report_id,version):
 with db() as c:
  r=getrow(c,'SELECT * FROM reports WHERE id=? AND version=?',(report_id,version))
  j=latest_render(c,report_id,version,r['sha256'])
  if not j: err(404,'Report not rendered')
  locked=getrow(c,'SELECT sha256 FROM render_manifests WHERE job_id=?',(j['id'],))
 return j['id'],locked['sha256']
@app.get('/web/v1/admin/reviews/{report_id}/{version}/artifacts',tags=['admin'])
def sme_artifacts(report_id:str,version:str,principal=Depends(_require_admin('report_review'))):
 base=f'/web/v1/admin/reviews/{quote(report_id,safe="")}/{quote(version,safe="")}/files/'
 return artifact_listing(report_id,version,lambda job_id,name:base+name,lambda sha:None)
@app.get('/web/v1/admin/reviews/{report_id}/{version}/files/assets/{asset_path:path}',tags=['admin'])
def sme_asset(report_id:str,version:str,asset_path:str,principal=Depends(_require_admin('report_review'))):
 job_id,package_sha=sme_render_job(report_id,version)
 return package_asset_bytes(package_sha,asset_path,public=False)
@app.get('/web/v1/admin/reviews/{report_id}/{version}/files/{name}',tags=['admin'])
def sme_file(report_id:str,version:str,name:str,principal=Depends(_require_admin('report_review'))):
 if name not in SME_FILES: err(404,'Artifact unavailable')
 job_id,package_sha=sme_render_job(report_id,version)
 return artifact_bytes(job_id,name,public=False)

# Reviewers (subject-matter experts) and their scopes from SCOOBY_REVIEWERS, so a host without a persistent
# disk still knows who they are. Invalid configuration loads nobody.
from publication import reviewers as publication_reviewers
publication_reviewers.load_from_env()
if web_origin:
 app.add_middleware(publication_admin_routes.AdminWebCORS, allow_origins=[web_origin], allow_credentials=False,
                    allow_methods=['GET','POST','DELETE'], allow_headers=['Content-Type','Authorization','Idempotency-Key'])

class PublicationWebCORS(CORSMiddleware):
 async def __call__(self, scope, receive, send):
  if scope['type'] == 'http' and scope['path'].startswith('/web/v1/') and not publication_admin_routes.cors_path(scope['path']):
   await super().__call__(scope, receive, send)
  else:
   await self.app(scope, receive, send)

if web_origin:
 app.add_middleware(PublicationWebCORS, allow_origins=[web_origin], allow_methods=['GET','POST'],
                    allow_headers=['Content-Type'])

class CaseWebCORS(CORSMiddleware):
 async def __call__(self,scope,receive,send):
  path=scope.get('path','')
  if scope['type']=='http' and ((path.startswith('/scouting/cases/') and path.endswith('/challenge')) or path.startswith('/scouting/challenges/') or path.startswith('/scouting/world-attempts/') or (path.startswith('/investigations/') and (path.endswith('/resume') or path.endswith('/events')))):
   await super().__call__(scope,receive,send)
  else:await self.app(scope,receive,send)
if web_origin:
 app.add_middleware(CaseWebCORS,allow_origins=[web_origin],allow_methods=['GET','POST'],allow_headers=['Content-Type','Authorization','Idempotency-Key'])

class CaseScan(BaseModel):
 limit: int = Field(default=10,ge=1,le=25)
class ChallengeRequest(BaseModel):
 action: Literal['diagnostic_research'] = 'diagnostic_research'
 expected_revision: str = Field(pattern=r'^[0-9a-f]{64}$')
@app.post('/scouting/cases/refresh')
def refresh_cases(x:CaseScan,idempotency_key:str=Header(None)):
 with db() as c:
  try: jid=job(c,'case_scan',str(x.limit),key(idempotency_key))
  except ValueError: err(409,'Idempotency key conflict')
 signal();return {'job_id':jid,'status':'queued','scope':'configured local discovery store; no network calls'}
def case_policy_digest():
 try:return __import__('case_engine').policy_digest()
 except (OSError,RuntimeError,ValueError):err(503,'Case policy source or budget configuration changed or is unavailable; restart after review')
def scouting_clues(record,captured):
 evidence={e['id']:e for e in record.get('evidence',[])};clues=[]
 for trigger in record.get('triggers',[]):
  for evidence_id in trigger.get('evidence_ids',[]) or [None]:
   e=evidence.get(evidence_id,{})
   clues.append({'kind':'discovery_trigger','description':trigger['description'],'evidence_id':evidence_id,'observed_at':e.get('observed_at'),'fetched_at':e.get('fetched_at'),'verification':'unverified_provider_lead'})
 # Project a narrow, labeled allowlist of provider claims from the already captured, hash-bound evidence.
 for e in record.get('evidence',[]):
  if not any('api.gopluslabs.io/api/v1/token_security/' in x for x in e.get('limitations',[])):continue
  try:
   raw=base64.b64decode(captured[e['source']],validate=True)
   if digest(raw)!=e['sha256']:continue
   data=json.loads(raw);results=data.get('result',{});address=record['identity']['address'].lower();token=next(v for k,v in results.items() if k.lower()==address and isinstance(v,dict))
   descriptions=[]
   if token.get('creator_percent')=='1.000000':descriptions.append('GoPlus reported creator balance equal to 100% of supply; the measurement time is unknown and the claim needs independent verification.')
   n=token.get('honeypot_with_same_creator')
   if isinstance(n,str) and n.isdigit() and 0<int(n)<=1000000:descriptions.append('GoPlus reported '+n+' honeypot(s) associated with the same creator; the claim and attribution are unverified.')
   if token.get('is_proxy')=='1':descriptions.append('GoPlus reported a proxy; its implementation and control require independent review.')
   for description in descriptions:clues.append({'kind':'provider_claim','description':description,'evidence_id':e['id'],'observed_at':e.get('observed_at'),'fetched_at':e.get('fetched_at'),'verification':'unverified_provider_claim'})
  except (ValueError,TypeError,KeyError,StopIteration,AttributeError):continue
 return clues

def case_view(c,case,policy=None):
 import datetime as dt
 policy=policy or case_policy_digest()
 snap=getrow(c,'SELECT * FROM case_snapshots WHERE id=?',(case['current_snapshot'],));record=json.loads(snap['record']);ass=json.loads(snap['assessment']);state=case['state']
 decision=c.execute("SELECT investigations.id AS run_id,investigations.status,case_decisions.budget FROM investigations LEFT JOIN case_decisions ON case_decisions.run_id=investigations.id WHERE investigations.candidate_id=? AND investigations.status!='reference_only' ORDER BY investigations.created DESC LIMIT 1",(case['candidate_id'],)).fetchone()
 if decision: state='investigating' if decision['status'] in ('queued','running') else 'research_partial' if decision['status']=='partial' else 'research_complete' if decision['status']=='complete' else 'unavailable'
 captured=json.loads(snap['evidence'])
 expected=digest(dumps({'record':record,'evidence':captured,'policy':snap['policy_digest'],'assessment':ass}).encode())
 if expected!=snap['id']: err(409,'Case snapshot integrity failure')
 if (snap['expires']<=now() or policy!=snap['policy_digest']) and state!='investigating': state='unavailable'
 lane={'monitoring':'monitoring','awaiting_human':'human_review_required','auto_queued':'auto_qualified','investigating':'research_running','research_partial':'research_partial','research_complete':'research_complete','unavailable':'unavailable'}[state]
 def latest(key):
  values=[e.get(key) for e in record.get('evidence',[]) if e.get(key)]
  try:return max(values,key=lambda x:dt.datetime.fromisoformat(x.replace('Z','+00:00'))) if values else None
  except (ValueError,TypeError):return None
 reasons=[{'group_id':g['id'],'name':g.get('name',g['id']),'measurements':g.get('measurements',[]),'description':g['detail'],'verification_status':g['status'],'evidence_ids':[e['id'] for e in g.get('evidence',[])],'observed_at':max((e['observed_at'] for e in g.get('evidence',[])),default=None)} for g in ass['groups']]
 pillars=[row(x) for x in c.execute('SELECT pillar,status,detail FROM pillars WHERE run_id=? ORDER BY pillar',(decision['run_id'],))] if decision else []
 linked=c.execute('SELECT id,version FROM reports WHERE run_id=? ORDER BY created DESC LIMIT 1',(decision['run_id'],)).fetchone() if decision else None
 _,count,_=__import__('case_engine').verified_gate(ass,captured)
 clues=scouting_clues(record,captured); fetched=latest('fetched_at'); observed=latest('observed_at')
 try:
  ages=[(dt.datetime.now(dt.timezone.utc)-dt.datetime.fromisoformat(t.replace('Z','+00:00'))).total_seconds() for t in (fetched,observed) if t]
  freshness='stale' if any(age>3600 for age in ages) else 'unknown' if not fetched or not observed or any(age<0 for age in ages) else 'fresh'
 except (ValueError,TypeError):freshness='unknown'
 world_ready=__import__('case_world').admin_ready(get_world_optional())
 remaining=max(0,4-count); has_concern=any(x['kind']=='provider_claim' for x in clues)
 if lane=='research_running':routing='Investigation is running; report will appear here when generated.'
 elif lane=='research_partial':routing='Partial investigation report is available; review its coverage and limitations.'
 elif lane=='research_complete':routing='Investigation report is available for review.'
 elif count>=4:routing='Four fresh independently verified concern groups qualify this case for automatic investigation.'
 elif has_concern:routing='Review the unverified provider concern; '+str(count)+'/4 fresh groups verified. World ID is required to start an exception.'
 else:routing='New-pool lead needs evidence of concern; '+str(count)+'/4 fresh groups verified. World ID is required to start an exception.'
 if freshness!='fresh':routing+=' Refresh evidence before acting.'
 summary=next((x['description'] for x in clues if x['kind']=='provider_claim'),None) or next((x['description'] for x in clues), 'No captured discovery trigger is available.')
 # A concrete provider claim raises review urgency within the same verified tier; it never adds gate votes.
 priority=(12-min(count,12))*2+(0 if has_concern else 1)+(60 if lane in ('research_running','research_partial','research_complete') else 100 if lane=='unavailable' else 0)
 return {'case_id':case['id'],'candidate_id':record['candidate_id'],'identity':record['identity'],'mode':record['mode'],'reference':None,'lane':lane,'human_action_required':lane=='human_review_required','priority_order':priority,'verified_triggered_count':count,'status_label':lane.replace('_',' '),'summary':summary,'scouting_clues':clues,'routing_rationale':routing,'evidence_freshness':freshness,'uncertainties':record['screening'].get('quality_issues',[]),'observed_at':latest('observed_at'),'fetched_at':latest('fetched_at'),'reasons':reasons,'snapshot_digest':snap['id'],'policy_digest':snap['policy_digest'],'expires_at':dt.datetime.fromtimestamp(snap['expires'],dt.timezone.utc).isoformat(),'continuation':{'availability':'available' if world_ready and lane in ('human_review_required','monitoring') and snap['expires']>now() else 'unavailable','reason':'World ID confirmation required for this case.' if world_ready else 'World ID administrator authorization is not configured.','action_url':('/scouting/cases/'+case['id']+'/challenge') if world_ready and lane in ('human_review_required','monitoring') and snap['expires']>now() else None,'expected_revision':snap['id']},'research':{'run_id':decision['run_id'],'status':decision['status'],'report_id':linked['id'] if linked else None,'report_version':linked['version'] if linked else None,'budget':json.loads(decision['budget']) if decision['budget'] else None,'authorization':('world_id_human' if decision['run_id'] and c.execute("SELECT 1 FROM case_decisions WHERE run_id=? AND action='human_research'",(decision['run_id'],)).fetchone() else 'policy_qualified_local') if decision['budget'] else 'unverified_legacy','pillars':pillars,'reason':'No usable evidence under the authorized budget; no report generated.' if decision['status']=='blocked' else 'Evidence-linked draft is partial and pending review.' if decision['status']=='partial' else 'Research is incomplete; inspect the per-pillar states.' if decision['status']=='incomplete' else None} if decision else None}
@app.get('/cases')
@app.get('/scouting/cases')
def scouting_cases():
 import datetime as dt
 with db() as c:
  total=c.execute('SELECT count(*) FROM cases').fetchone()[0]
  if total>5000: err(503,'Case index exceeds bounded list capacity; cursor pagination required')
  policy=case_policy_digest();items=[case_view(c,x,policy) for x in c.execute('SELECT * FROM cases').fetchall()]
 items.sort(key=lambda x:(x['priority_order'],x['candidate_id']))
 return {'schema_version':'scouting-case-list/2','generated_at':dt.datetime.now(dt.timezone.utc).isoformat(),'stale_after_seconds':60,'cases':items[:100],'truncated':total>100,'authentication':'none; local operator prototype'}
@app.get('/cases/{case_id}')
@app.get('/scouting/cases/{case_id}')
def scouting_case(case_id:str):
 with db() as c:return case_view(c,getrow(c,'SELECT * FROM cases WHERE id=?',(case_id,)))
@app.post('/scouting/cases/{case_id}/challenge')
def challenge(case_id:str,x:ChallengeRequest,idempotency_key:str=Header(None),principal=Depends(_require_admin('case_investigation'))):
 import secrets
 k=key(idempotency_key)
 with db() as c:
  c.execute('BEGIN IMMEDIATE');case=getrow(c,'SELECT * FROM cases WHERE id=?',(case_id,));snap=getrow(c,'SELECT * FROM case_snapshots WHERE id=?',(case['current_snapshot'],))
  old=c.execute('SELECT * FROM case_challenges WHERE idem=?',(k,)).fetchone()
  if old:
   __import__('case_world').require_owner(c,old['id'],principal)
   if (old['case_id'],old['snapshot_id'],old['action'])!=(case_id,x.expected_revision,x.action):err(409,'Idempotency key conflict')
   old_state=old['state']
   if old_state=='pending' and old['expires']<=now():old_state='expired'
   if old_state=='pending' and (case['current_snapshot']!=old['snapshot_id'] or case_policy_digest()!=old['policy_digest']):old_state='superseded'
   return {'challenge_id':old['id'],'case_id':case_id,'candidate_id':case['candidate_id'],'snapshot_digest':old['snapshot_id'],'policy_digest':old['policy_digest'],'action':old['action'],'nonce':old['nonce'],'state':old_state,'expires_at':old['expires'],'verification':'configured' if __import__('case_world').admin_ready(get_world_optional()) else 'unavailable'}
  if snap['id']!=x.expected_revision or snap['expires']<=now() or case_policy_digest()!=snap['policy_digest']:err(409,'Snapshot is stale or superseded')
  if case['state'] not in ('awaiting_human','monitoring'):err(409,'Case is not awaiting an exception')
  i=ident();nonce=secrets.token_hex(32);expires=min(snap['expires'],now()+900)
  c.execute('INSERT INTO case_challenges VALUES(?,?,?,?,?,?,?,?,?,?)',(i,case_id,snap['id'],snap['policy_digest'],x.action,nonce,'pending',expires,now(),k))
  c.execute('INSERT INTO case_challenge_admin VALUES(?,?,?)',(i,principal.session_id,publication_admin.subject_hash(principal.iss,principal.sub)))
  c.execute("UPDATE cases SET state='awaiting_human',updated=? WHERE id=?",(now(),case_id))
  return {'challenge_id':i,'case_id':case_id,'candidate_id':case['candidate_id'],'snapshot_digest':snap['id'],'policy_digest':snap['policy_digest'],'action':x.action,'nonce':nonce,'state':'pending','expires_at':expires,'verification':'configured' if __import__('case_world').admin_ready(get_world_optional()) else 'unavailable'}
@app.post('/scouting/challenges/{challenge_id}/continue')
def continue_challenge(challenge_id:str,principal=Depends(_require_admin('case_investigation'))):
 # Fail closed until the separately owned verifier checks action, identity, nonce, expiry and revocation.
 with db() as c:
  challenge=getrow(c,'SELECT * FROM case_challenges WHERE id=?',(challenge_id,))
  __import__('case_world').require_owner(c,challenge_id,principal)
  if challenge['state']!='pending' or challenge['expires']<=now():err(409,'Challenge is expired or superseded')
  case=getrow(c,'SELECT * FROM cases WHERE id=?',(challenge['case_id'],))
  if case['current_snapshot']!=challenge['snapshot_id'] or case_policy_digest()!=challenge['policy_digest']:err(409,'Challenge is stale or superseded')
 err(503,'Authenticated human verification adapter is not configured')

@app.get('/scouting/challenges/{challenge_id}')
def challenge_status(challenge_id:str,principal=Depends(_require_admin('case_investigation'))):
 with db() as c:
  challenge=getrow(c,'SELECT * FROM case_challenges WHERE id=?',(challenge_id,));__import__('case_world').require_owner(c,challenge_id,principal);case=getrow(c,'SELECT * FROM cases WHERE id=?',(challenge['case_id'],));state=challenge['state']
  if state=='pending' and challenge['expires']<=now():state='expired'
  if state=='pending' and (case['current_snapshot']!=challenge['snapshot_id'] or case_policy_digest()!=challenge['policy_digest']):state='superseded'
  return {'challenge_id':challenge_id,'candidate_id':case['candidate_id'],'snapshot_digest':challenge['snapshot_id'],'policy_digest':challenge['policy_digest'],'action':challenge['action'],'nonce':challenge['nonce'],'expires_at':challenge['expires'],'state':state,'verification':'configured' if __import__('case_world').admin_ready(get_world_optional()) else 'unavailable'}
@app.post('/scouting/challenges/{challenge_id}/world-attempt')
def case_world_start(challenge_id:str,world=Depends(get_world_optional),principal=Depends(_require_admin('case_investigation'))):
 import case_world
 return case_world.start(challenge_id,world,principal)
@app.get('/scouting/world-attempts/{attempt_id}')
def case_world_poll(attempt_id:str,world=Depends(get_world_optional),principal=Depends(_require_admin('case_investigation'))):
 import case_world
 result=case_world.poll(attempt_id,world,principal)
 if result['state']=='approved':signal()
 return result

@app.post('/scouting/world-attempts/{attempt_id}/cancel')
def case_world_cancel(attempt_id:str,principal=Depends(_require_admin('case_investigation'))):
 import case_world
 return case_world.cancel(attempt_id,principal)

@app.post('/scouting/challenges/{challenge_id}/{human_action}')
def human_challenge_action(challenge_id:str,human_action:Literal['deny','revoke','revise'],principal=Depends(_require_admin('case_investigation'))):
 if human_action=='revise':err(503,'Revision requires a new discovery snapshot')
 import case_world
 with db() as c:
  c.execute('BEGIN IMMEDIATE');ch=getrow(c,'SELECT * FROM case_challenges WHERE id=?',(challenge_id,));case_world.require_owner(c,challenge_id,principal)
  if ch['state']=='pending':
   c.execute("UPDATE case_challenges SET state=? WHERE id=?",('denied' if human_action=='deny' else 'revoked',challenge_id))
   attempts=c.execute("SELECT id FROM case_world_attempts WHERE challenge_id=? AND state='pending'",(challenge_id,)).fetchall()
   c.execute("UPDATE case_world_attempts SET state='cancelled' WHERE challenge_id=? AND state='pending'",(challenge_id,))
   with case_world._lock:
    for attempt in attempts:case_world._codes.pop(attempt['id'],None)
  return {'challenge_id':challenge_id,'state':getrow(c,'SELECT state FROM case_challenges WHERE id=?',(challenge_id,))['state']}

def social_context_file(path):
 # Explicitly configured local metadata only. Read on demand; never copy into the database or reports.
 unavailable={'leads':[],'status':'unavailable','reason':'No current bounded SearchApi metadata is configured.','provider':'searchapi.io'}
 if not path:return unavailable
 try:
  p=Path(path)
  if p.stat().st_size>262144:raise ValueError('metadata too large')
  data=json.loads(p.read_text(encoding='utf-8-sig'))
  if data.get('profile')!='scooby.reddit-leads/1' or data.get('provider')!='searchapi.io':raise ValueError('unsupported metadata')
  observations=data['observations']
  if not isinstance(observations,list) or len(observations)>40:raise ValueError('invalid observations')
  leads=[];current=datetime.datetime.now(datetime.timezone.utc)
  for item in observations:
   fetched=datetime.datetime.fromisoformat(item['fetched_at'].replace('Z','+00:00'));observed=datetime.datetime.fromisoformat(item['observed_at'].replace('Z','+00:00'))
   age=(current-fetched).total_seconds()
   if fetched.tzinfo is None or observed.tzinfo is None or age<0 or age>86400 or observed>fetched:raise ValueError('stale or invalid observation')
   url=item['url'];parts=urlsplit(url)
   if parts.scheme!='https' or parts.hostname not in ('www.reddit.com','reddit.com') or parts.username or parts.password or len(url)>2048:raise ValueError('invalid URL')
   ident=item['id'];sub=item['subreddit']
   if not isinstance(ident,str) or not ident.startswith('t3_') or not ident[3:].isalnum() or not isinstance(sub,str) or not sub.replace('_','').isalnum() or len(sub)>32:raise ValueError('invalid identity')
   leads.append({'id':ident,'url':url,'subreddit':sub,'observed_at':observed.isoformat(),'fetched_at':fetched.isoformat(),'age_days':round((current-observed).total_seconds()/86400,2),'source_mode':'dated_social_context','attribution':'unresolved','verified_concern_votes':0})
  return {'leads':leads,'status':'partial','provider':'searchapi.io','reason':'Historical context only; attribution unresolved and research integration incomplete. Metadata expires 24 hours after fetch.','coverage':{'posts_examined':len(leads),'complete':False},'storage':'read-only external metadata; not persisted by backend'}
 except (OSError,ValueError,TypeError,KeyError,AttributeError,OverflowError):return unavailable

def social_context():
 paths=[p for p in (os.getenv('SCOOBY_SOCIAL_CONTEXT_FILES','') or os.getenv('SCOOBY_SOCIAL_CONTEXT_FILE','')).split(os.pathsep) if p.strip()][:3]
 results=[social_context_file(p.strip()) for p in paths];good=[r for r in results if r['status']=='partial'];leads=[];seen=set()
 for result in good:
  for lead in result['leads']:
   if lead['id'] not in seen:leads.append(lead);seen.add(lead['id'])
 return {'leads':leads,'status':'partial' if good else 'unavailable','provider':'searchapi.io','reason':'Historical context only; attribution unresolved and research integration incomplete.' if good else 'No current bounded SearchApi metadata is configured.','coverage':{'configured_feeds':len(paths),'available_feeds':len(good),'complete':False},'storage':'read-only external metadata; not persisted by backend'}

def candidate_social_status():
 path=os.getenv('SCOOBY_SOCIAL_CANDIDATE_STATUS_FILE','').strip()
 if not path:return []
 try:
  p=Path(path)
  if p.stat().st_size>262144:raise ValueError('metadata too large')
  data=json.loads(p.read_text(encoding='utf-8-sig'));candidate=data['candidate_id'];end=datetime.datetime.fromisoformat(data['window']['end'].replace('Z','+00:00'));age=(datetime.datetime.now(datetime.timezone.utc)-end).total_seconds()
  chain,address=candidate.split(':',1)
  if data['profile']!='scooby.reddit-evidence/1' or data['provider']!='searchapi.io' or data['coverage']['reason']!='provider_error' or data['observations'] or chain not in ('1','8453') or len(address)!=42 or not address.startswith('0x') or any(c not in '0123456789abcdefABCDEF' for c in address[2:]) or not 0<=age<=86400:raise ValueError('unsupported status')
  return [{'candidate_id':candidate,'status':'unavailable','reason':'provider_error','interpretation':'unavailable','observation_count':0}]
 except (OSError,ValueError,TypeError,KeyError,AttributeError,OverflowError):return []

@app.get('/scouting/social-candidate-status')
def scouting_social_candidate_status():
 return {'candidate_queries':candidate_social_status(),'provider':'searchapi.io'}

@app.get('/scouting/sources')
def scouting_sources():
 context=social_context()
 with db() as c:sources=[row(x) for x in c.execute('SELECT * FROM case_sources ORDER BY id')]
 for source in sources:
  if source['id']=='reddit' and context['status']=='partial':source.update(status='partial',detail='SearchApi metadata is available as historical context; identity resolution and durable lifecycle remain incomplete.')
 return {'sources':sources,'reddit_lead_storage':'blocked_pending_retention_and_deletion_review','authentication':'none; local operator prototype'}
@app.get('/scouting/leads')
def scouting_leads():
 return social_context()

@app.get('/scouting/schema')
def scouting_schema():
 path=ROOT/'schemas/runtime/scouting-case-list-v2.schema.json';raw=path.read_bytes()
 return {'schema_version':'scouting-case-list/2','sha256':digest(raw),'schema':json.loads(raw)}
# Public-host gate (SCOOBY_PUBLIC_GATE=true, e.g. on Render). Deny by default: anonymous callers reach only
# /health, the /web/v1 adapter and /publication/v1 (whose writes require the operator bearer token). Every
# other route, including /docs and /openapi.json, requires `Authorization: Bearer $SCOOBY_OPERATOR_TOKEN`.
# Without a configured token those routes are closed. This is a stopgap, not the reviewed gateway in DEPLOYMENT.md.
PUBLIC_EXACT=frozenset({'/health'})
PUBLIC_PREFIXES=('/web/v1/','/publication/v1/')
# Public report library, GET/HEAD only: list, per-version artifacts, packages and rendered files.
import re as _re
PUBLIC_LIBRARY=_re.compile(r'^/(reports|reports/[^/]+/[^/]+/artifacts|packages/[0-9a-f]{64}(/.+)?|artifacts/[^/]+/.+)$')
SCOUT_READ=_re.compile(r'^/scouting/(?:cases(?:/[^/]+)?|schema)$')
CASE_AUTH=_re.compile(r'^/scouting/(?:cases/[^/]+/challenge|challenges/[^/]+(?:/(?:world-attempt|continue|deny|revoke|revise))?|world-attempts/[^/]+(?:/cancel)?)$')
CASE_PROGRESS=_re.compile(r'^/investigations/[^/]+/(?:events|resume)$')
def _public_path(path,method='GET'):
 if path in PUBLIC_EXACT or path.startswith(PUBLIC_PREFIXES): return True
 if method in ('GET','HEAD') and SCOUT_READ.fullmatch(path) and path!='/scouting/cases/refresh': return True
 if method in ('GET','POST','OPTIONS') and CASE_AUTH.fullmatch(path): return True
 if method in ('GET','POST','OPTIONS') and CASE_PROGRESS.fullmatch(path): return True
 return method in ('GET','HEAD') and bool(PUBLIC_LIBRARY.match(path))
class PublicGate:
 def __init__(self, app): self.app=app
 async def __call__(self, scope, receive, send):
  if scope['type']!='http' or os.getenv('SCOOBY_PUBLIC_GATE','').strip().lower() not in ('1','true','yes','on'):
   return await self.app(scope, receive, send)
  path=scope['path']
  # Public paths must be plain (no encoded or traversal segments) so prefix matching cannot be bypassed.
  plain=not ('..' in path or '//' in path or '\\' in path or b'%' in (scope.get('raw_path') or b''))
  if plain and _public_path(path,scope.get('method','GET')): return await self.app(scope, receive, send)
  token=os.getenv('SCOOBY_OPERATOR_TOKEN') or ''
  supplied=dict(scope.get('headers') or []).get(b'authorization',b'').decode('latin-1').removeprefix('Bearer ').strip()
  if token and supplied and hmac.compare_digest(supplied.encode(), token.encode()):
   return await self.app(scope, receive, send)
  return await _deny(send, 404)
async def _deny(send, code):
 body=b'{"detail":"Not found"}'
 await send({'type':'http.response.start','status':code,'headers':[(b'content-type',b'application/json'),(b'content-length',str(len(body)).encode())]})
 await send({'type':'http.response.body','body':body})
app.add_middleware(PublicGate)
